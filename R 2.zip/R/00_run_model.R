###############################################################
# Tick Persistence Framework
# MASTER SCRIPT
#
# Run ONLY this file
###############################################################

rm(list = ls())

graphics.off()

cat("\014")
setwd("/Users/kagboka/Desktop/R.appendi")
###############################################################
## Packages
###############################################################

library(ggplot2)
library(dplyr)
library(tidyr)

###############################################################
## Working directory
###############################################################

# setwd("C:/...")

###############################################################
## Load model
###############################################################

###############################################################
## Load model
###############################################################

source("R/01_parameters.R")
source("R/02_development.R")
source("R/03_mortality.R")
source("R/04_fecundity.R")
source("R/05_persistence.R")
source("R/06_uncertainty.R")
source("R/08_figures.R")
source("R/09_biological_verification.R")

###############################################################
## Run inspection
###############################################################

cat("\n")
cat("=====================================\n")
cat(" Tick Persistence Framework\n")
cat("=====================================\n\n")

###############################################################
## Development
###############################################################

cat("Running development module...\n")

Temperature <- seq(10,40,0.25)

Development <- development_rates(Temperature)

print(head(Development))

###############################################################
## Mortality
###############################################################

cat("Running mortality module...\n")

Mortality <- mortality_rates(
  
  Temperature,
  
  RH=85
  
)

print(head(Mortality))

###############################################################
## Fecundity
###############################################################

cat("Running fecundity module...\n")

Fsummary <- fecundity_summary()

print(Fsummary)

###############################################################
## Persistence
###############################################################

cat("Running persistence module...\n")

P25 <- Persistence(
  
  T=25,
  
  RH=85
  
)

print(P25)

###############################################################
## Temperature profile
###############################################################

cat("Temperature profile...\n")

PT <- TemperatureProfile(
  
  T=Temperature,
  
  RH=85,
  
  nsim=1000
  
)

print(head(PT))

###############################################################
## Humidity profile
###############################################################

cat("Humidity profile...\n")

Humidity <- seq(40,100,1)

PH <- HumidityProfile(
  
  RH=Humidity,
  
  T=25,
  
  nsim=1000
  
)

print(head(PH))

###############################################################
## Produce manuscript figures
###############################################################

cat("Generating figures...\n")

SaveFigures()

###############################################################
## Run biological inspection
###############################################################

cat("Running biological inspection...\n")

source("R/09_biological_verification.R")

###############################################################
## Finished
###############################################################

cat("\n")
cat("=====================================\n")
cat(" Framework completed successfully.\n")
cat("=====================================\n")

