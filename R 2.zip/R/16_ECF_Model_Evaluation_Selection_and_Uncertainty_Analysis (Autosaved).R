################################################################################
# 16_ECF_Model_Evaluation_Selection_and_Uncertainty_Analysis_v2.R
#
# PART 1: INITIALIZATION AND AUTOMATIC DISCOVERY
################################################################################

rm(list = ls())
gc()

cat("\014")

################################################################################
# Libraries
################################################################################

required_packages <- c(
  "terra",
  "sf",
  "dplyr",
  "stringr",
  "purrr",
  "tidyr",
  "ggplot2",
  "ecospat",
  "pROC",
  "effsize"
)
invisible(
  lapply(required_packages, library,
         character.only = TRUE)
)

################################################################################
# Directories
################################################################################

project_dir <- "/Users/kagboka/Desktop/R.appendi"

prediction_dir <- file.path(
  project_dir,
  "ECF_PostProcessed"
)

evaluation_dir <- file.path(
  project_dir,
  "Outputs",
  "16_Model_Evaluation_v2"
)

dir.create(
  evaluation_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

################################################################################
# Occurrence data
################################################################################

occ <- read.csv(
  file.path(
    project_dir,
    "ECF_Occurrence_Sites.csv"
  )
)

occ <- occ %>%
  dplyr::filter(Presence == 1)

cat("Occurrence records :", nrow(occ), "\n")

occ_vect <- terra::vect(
  occ,
  geom = c("East","North"),
  crs = "EPSG:4326"
)

################################################################################
# Discover prediction rasters
################################################################################

prediction_files <- list.files(
  prediction_dir,
  recursive = TRUE,
  full.names = TRUE,
  pattern = "\\.nc$"
)

cat("Prediction files discovered :", length(prediction_files), "\n")

if(length(prediction_files)==0)
  stop("No NetCDF files found.")

################################################################################
# Build raster inventory
################################################################################

PredictionInventory <- purrr::map_df(
  prediction_files,
  function(f){
    
    r <- terra::rast(f)
    
    data.frame(
      
      File = f,
      
      Filename = basename(f),
      
      Folder = basename(dirname(f)),
      
      Product = tools::file_path_sans_ext(
        basename(f)
      ),
      
      NLayers = terra::nlyr(r),
      
      NRows = nrow(r),
      
      NCols = ncol(r),
      
      Resolution_X = terra::res(r)[1],
      
      Resolution_Y = terra::res(r)[2],
      
      CRS = terra::crs(r),
      
      stringsAsFactors = FALSE
      
    )
    
  }
)

################################################################################
# Classify product family
################################################################################

PredictionInventory$Family <- case_when(
  
  str_detect(
    PredictionInventory$Product,
    "Monthly"
  ) ~ "Monthly",
  
  str_detect(
    PredictionInventory$Product,
    "Seasonal"
  ) ~ "Seasonal",
  
  str_detect(
    PredictionInventory$Product,
    "Quarterly"
  ) ~ "Quarterly",
  
  str_detect(
    PredictionInventory$Product,
    "Persistence"
  ) ~ "Persistence",
  
  str_detect(
    PredictionInventory$Product,
    "Suitable"
  ) ~ "SuitableDays",
  
  str_detect(
    PredictionInventory$Product,
    "Trend"
  ) ~ "Trend",
  
  str_detect(
    PredictionInventory$Product,
    "Variability"
  ) ~ "Variability",
  
  TRUE ~ "Other"
  
)

################################################################################
# Which products are suitable for Boyce?
################################################################################

PredictionInventory$EvaluateBoyce <-
  stringr::str_detect(
    PredictionInventory$Filename,
    "LongTermMean"
  )

################################################################################
# Create evaluation inventory
################################################################################

EvaluationInventory <-
  PredictionInventory %>%
  dplyr::filter(EvaluateBoyce)

cat("\n")
cat("Products selected for Boyce evaluation:\n")
print(EvaluationInventory[, c("Filename", "Folder")])
write.csv(
  EvaluationInventory,
  file.path(
    evaluation_dir,
    "EvaluationInventory.csv"
  ),
  row.names = FALSE
)
################################################################################
# Save inventory
################################################################################

write.csv(
  PredictionInventory,
  file.path(
    evaluation_dir,
    "PredictionInventory.csv"
  ),
  row.names = FALSE
)

################################################################################
# Summary
################################################################################

cat("\n")
cat("=========================================\n")
cat("Prediction Inventory\n")
cat("=========================================\n")

print(
  PredictionInventory %>%
    count(Family)
)

cat("\nProducts selected for Boyce evaluation:\n")

print(
  PredictionInventory %>%
    filter(EvaluateBoyce)
)



################################################################################
# PART 2 : BUILD EVALUATION DATASET
################################################################################

cat("\n")
cat("=========================================\n")
cat("Preparing evaluation dataset\n")
cat("=========================================\n")

################################################################################
# Reference raster
################################################################################

reference_file <-
  PredictionInventory %>%
  slice(1) %>%
  pull(File)

reference_raster <-
  terra::rast(reference_file)

# Always use first layer as spatial reference
reference_raster <-
  reference_raster[[1]]

################################################################################
# Sample valid cells
################################################################################

valid_cells <-
  which(
    !is.na(
      terra::values(reference_raster)
    )
  )

cat("Valid raster cells:",
    length(valid_cells),
    "\n")

################################################################################
# Background points
################################################################################

set.seed(1234)

n_background <-
  min(
    10000,
    length(valid_cells)
  )

selected_cells <-
  sample(
    valid_cells,
    n_background
  )

xy <-
  terra::xyFromCell(
    reference_raster,
    selected_cells
  )

background <-
  data.frame(
    
    East = xy[,1],
    
    North = xy[,2]
    
  )

################################################################################
# Convert to sf
################################################################################

background_sf <-
  sf::st_as_sf(
    
    background,
    
    coords = c("East","North"),
    
    crs = 4326
    
  )

################################################################################
# Save
################################################################################

write.csv(
  
  background,
  
  file.path(
    evaluation_dir,
    "Background_Points.csv"
  ),
  
  row.names = FALSE
  
)

################################################################################
# Summary
################################################################################

cat("\n")

cat("Presence records :",
    nrow(occ),
    "\n")

cat("Background points:",
    nrow(background),
    "\n")

cat("Evaluation dataset ready.\n")

################################################################################
# PART 3 : LOAD LONG-TERM MEAN INTEGRATION HYPOTHESES
################################################################################

cat("\n")
cat("=========================================\n")
cat("Loading ecological integration hypotheses\n")
cat("=========================================\n")

###############################################################################
# Keep only LongTermMean products
###############################################################################

EvaluationInventory <-
  PredictionInventory %>%
  dplyr::filter(
    stringr::str_detect(Product,"LongTermMean")
  )

###############################################################################
# Remove products that are NOT integration hypotheses
###############################################################################

EvaluationInventory <-
  EvaluationInventory %>%
  dplyr::filter(
    !stringr::str_detect(
      Product,
      "Monthly|Seasonal|Quarterly|Trend|Variability|PersistenceFrequency|SuitableDays"
    )
  )

cat("Integration hypotheses found:\n")

print(EvaluationInventory$Product)

###############################################################################
# Read rasters
###############################################################################

PredictionSurfaces <- vector(
  "list",
  nrow(EvaluationInventory)
)

for(i in seq_len(nrow(EvaluationInventory))){
  
  r <- terra::rast(
    EvaluationInventory$File[i]
  )
  
  if(terra::nlyr(r)>1){
    
    r <- terra::app(
      r,
      mean,
      na.rm=TRUE
    )
    
  }
  
  ##########################################################################
  # Clean ecological hypothesis name
  ##########################################################################
  
  MethodName <-
    EvaluationInventory$Product[i]
  
  MethodName <-
    stringr::str_remove(
      MethodName,
      "\\.nc$"
    )
  
  MethodName <-
    stringr::str_remove(
      MethodName,
      "_LongTermMean"
    )
  
  MethodName <-
    stringr::str_remove(
      MethodName,
      "LongTermMean_"
    )
  
  MethodName <-
    stringr::str_replace_all(
      MethodName,
      "_",
      " "
    )
  
  PredictionSurfaces[[i]] <-
    list(
      
      Method = MethodName,
      
      Raster = r
      
    )
  
  cat(
    sprintf(
      "%2d  %s\n",
      i,
      MethodName
    )
  )
  
}


################################################################################
# PART 4 : PAIRWISE SIMILARITY AMONG ECOLOGICAL INTEGRATION HYPOTHESES
################################################################################

cat("\n")
cat("=========================================\n")
cat("Pairwise similarity among integration hypotheses\n")
cat("=========================================\n")

###############################################################################
# Build raster matrix
###############################################################################

###############################################################################
# Raster matrix
###############################################################################

RasterMatrix <-
  do.call(
    cbind,
    lapply(
      PredictionSurfaces,
      function(x){
        
        terra::values(x$Raster)
        
      }
    )
  )

RasterMatrix <-
  RasterMatrix[
    complete.cases(RasterMatrix),
  ]

MethodNames <-
  sapply(
    PredictionSurfaces,
    function(x)x$Method
  )

colnames(RasterMatrix) <- MethodNames
###############################################################################
# Remove missing pixels
###############################################################################

RasterMatrix <-
  RasterMatrix[
    complete.cases(RasterMatrix),
  ]

cat(
  "Pixels used:",
  nrow(RasterMatrix),
  "\n"
)

###############################################################################
# Pearson correlation
###############################################################################

PearsonMatrix <-
  cor(
    RasterMatrix,
    method="pearson"
  )

###############################################################################
# Spearman correlation
###############################################################################

SpearmanMatrix <-
  cor(
    RasterMatrix,
    method="spearman"
  )

###############################################################################
# Schoener's D
###############################################################################

SchoenerD <- function(x,y){
  
  x <- x/sum(x)
  
  y <- y/sum(y)
  
  1 - 0.5*sum(abs(x-y))
  
}

###############################################################################
# Warren's I
###############################################################################

WarrenI <- function(x,y){
  
  x <- x/sum(x)
  
  y <- y/sum(y)
  
  (sum(sqrt(x*y)))^2
  
}

###############################################################################
# Compute pairwise indices
###############################################################################

Methods <- colnames(RasterMatrix)

n <- length(Methods)

Dmatrix <-
  matrix(
    NA,
    n,
    n,
    dimnames=list(
      Methods,
      Methods
    )
  )

Imatrix <-
  Dmatrix

for(i in seq_len(n)){
  
  for(j in i:n){
    
    Dmatrix[i,j] <-
      SchoenerD(
        RasterMatrix[,i],
        RasterMatrix[,j]
      )
    
    Dmatrix[j,i] <-
      Dmatrix[i,j]
    
    Imatrix[i,j] <-
      WarrenI(
        RasterMatrix[,i],
        RasterMatrix[,j]
      )
    
    Imatrix[j,i] <-
      Imatrix[i,j]
    
  }
  
}

###############################################################################
# Save matrices
###############################################################################

write.csv(
  PearsonMatrix,
  file.path(
    evaluation_dir,
    "PearsonCorrelation.csv"
  )
)

write.csv(
  SpearmanMatrix,
  file.path(
    evaluation_dir,
    "SpearmanCorrelation.csv"
  )
)

write.csv(
  Dmatrix,
  file.path(
    evaluation_dir,
    "SchoenersD.csv"
  )
)

write.csv(
  Imatrix,
  file.path(
    evaluation_dir,
    "WarrensI.csv"
  )
)

cat("Similarity matrices saved.\n")



################################################################################
# Function to plot similarity heatmaps
################################################################################

PlotHeatmap <- function(mat, title, filename){
  
  df <- as.data.frame(as.table(mat))
  
  names(df) <- c("Method1","Method2","Similarity")
  
  p <-
    
    ggplot(
      df,
      aes(
        Method1,
        Method2,
        fill = Similarity
      )
    )+
    
    geom_tile(color="white")+
    
    geom_text(
      aes(
        label=sprintf("%.2f",Similarity)
      ),
      size=3
    )+
    
    scale_fill_gradient2(
      
      low="#B2182B",
      
      mid="white",
      
      high="#2166AC",
      
      midpoint=0.75,
      
      limits=c(0,1),
      
      name="Similarity"
      
    )+
    
    coord_equal()+
    
    labs(
      
      x="",
      
      y="",
      
      title=title
      
    )+
    
    theme_bw(base_size=13)+
    
    theme(
      
      axis.text.x=
        element_text(
          angle=45,
          hjust=1
        ),
      
      panel.grid=element_blank(),
      
      plot.title=
        element_text(
          hjust=0.5,
          face="bold"
        )
      
    )
  
  ggsave(
    
    file.path(
      evaluation_dir,
      paste0(filename,".png")
    ),
    
    p,
    
    width=8,
    
    height=7,
    
    dpi=600
    
  )
  
  ggsave(
    
    file.path(
      evaluation_dir,
      paste0(filename,".pdf")
    ),
    
    p,
    
    width=8,
    
    height=7
    
  )
  
}

PlotHeatmap(
  PearsonMatrix,
  "Pearson correlation",
  "PearsonHeatmap"
)

PlotHeatmap(
  SpearmanMatrix,
  "Spearman correlation",
  "SpearmanHeatmap"
)

PlotHeatmap(
  Dmatrix,
  "Schoener's D",
  "SchoenersDHeatmap"
)

PlotHeatmap(
  Imatrix,
  "Warren's I",
  "WarrensIHeatmap"
)

######
library(ggplot2)
library(ggdendro)
library(patchwork)

###############################################################################
# Hierarchical clustering
###############################################################################

DistanceMatrix <- 1 - Dmatrix

hc <- hclust(
  as.dist(DistanceMatrix),
  method = "average"
)

###############################################################################
# Order heatmap
###############################################################################

ord <- hc$order

Dplot <- Dmatrix[
  ord,
  ord
]

HeatDF <- as.data.frame(as.table(Dplot))

colnames(HeatDF) <-
  c(
    "Method1",
    "Method2",
    "Similarity"
  )

PanelA <-
  
  ggplot(
    HeatDF,
    aes(
      Method1,
      Method2,
      fill=Similarity
    )
  )+
  
  geom_tile(
    colour="grey95",
    linewidth=.3
  )+
  
  scale_fill_gradient2(
    
    low="#B2182B",
    
    mid="white",
    
    high="#2166AC",
    
    midpoint=.75,
    
    limits=c(0,1),
    
    name="Schoener's D"
    
  )+
  
  coord_equal()+
  
  labs(
    
    title="A",
    
    x="",
    
    y=""
    
  )+
  
  theme_bw(base_size=16)+
  
  theme(
    
    plot.title=
      element_text(
        face="bold",
        size=22
      ),
    
    axis.text.x=
      element_text(
        angle=45,
        hjust=1,
        vjust=1
      ),
    
    panel.grid=
      element_blank(),
    
    axis.title=
      element_blank()
    
  )

###############################################################################
# Convert dendrogram to ggplot
###############################################################################

ddata <- ggdendro::dendro_data(
  as.dendrogram(hc)
)

PanelB <-
  
  ggplot()+
  
  geom_segment(
    
    data=ddata$segments,
    
    aes(
      
      x=x,
      
      y=y,
      
      xend=xend,
      
      yend=yend
      
    ),
    
    linewidth=.8,
    
    colour="black"
    
  )+
  
  geom_text(
    
    data=ddata$labels,
    
    aes(
      
      x=x,
      
      y=-0.02,
      
      label=label
      
    ),
    
    angle=90,
    
    hjust=1,
    
    size=4
    
  )+
  
  labs(
    
    title="B",
    
    y="Ecological distance\n(1 − Schoener's D)",
    
    x=""
    
  )+
  
  theme_bw(base_size=16)+
  
  theme(
    
    plot.title=
      element_text(
        face="bold",
        size=22
      ),
    
    panel.grid=
      element_blank(),
    
    axis.text.x=
      element_blank(),
    
    axis.ticks.x=
      element_blank()
    
  )+
  
  coord_cartesian(
    clip="off"
  )
FigureFinal <-
  
  PanelA +
  PanelB +
  
  plot_layout(
    
    widths=c(1.7,.9)
    
  )

ggsave(
  
  file.path(
    
    evaluation_dir,
    
    "Figure_EcologicalSimilarity.pdf"
    
  ),
  
  FigureFinal,
  
  width=14,
  
  height=8
  
)

ggsave(
  
  file.path(
    
    evaluation_dir,
    
    "Figure_EcologicalSimilarity.png"
    
  ),
  
  FigureFinal,
  
  width=14,
  
  height=8,
  
  dpi=600
  
)
################################################################################
# PART 5 : STATISTICAL COMPARISON OF ECOLOGICAL INTEGRATION HYPOTHESES
################################################################################

cat("\n")
cat("=============================================================\n")
cat("Statistical comparison of ecological integration hypotheses\n")
cat("=============================================================\n")

library(tidyr)
library(dplyr)
library(rstatix)
library(irr)

################################################################################
## Integration hypotheses
################################################################################

IntegrationMethods <- c(
  
  "Multiplicative",
  
  "Limiting",
  
  "Arithmetic",
  
  "Geometric",
  
  paste0("Weighted_", sprintf("%02d", seq(10,90,10))),
  
  "Fuzzy"
  
)

################################################################################
## Read long-term suitability maps
################################################################################

IntegrationRasters <- lapply(
  
  IntegrationMethods,
  
  function(m){
    
    rast(
      
      file.path(
        
        project_dir,
        
        "ECF_PostProcessed",
        
        "Variability",
        
        paste0(m,"_LongTermMean.nc")
        
      )
      
    )
    
  }
  
)

################################################################################
## Extract raster values
################################################################################

SuitabilityMatrix <- do.call(
  
  cbind,
  
  lapply(
    
    IntegrationRasters,
    
    terra::values
    
  )
  
)

colnames(SuitabilityMatrix) <- IntegrationMethods

################################################################################
## Remove NA pixels
################################################################################

SuitabilityMatrix <-
  
  SuitabilityMatrix[
    
    complete.cases(SuitabilityMatrix),
    
  ]

################################################################################
## Sample pixels (for computational efficiency)
################################################################################

set.seed(123)

MaxPixels <- 10000

if(nrow(SuitabilityMatrix) > MaxPixels){
  
  SuitabilityMatrix <-
    
    SuitabilityMatrix[
      
      sample(
        
        nrow(SuitabilityMatrix),
        
        MaxPixels
        
      ),
      
    ]
  
}

cat("Pixels analysed :",nrow(SuitabilityMatrix),"\n")

################################################################################
## Long format
################################################################################

SuitabilityLong <-
  
  as.data.frame(SuitabilityMatrix) |>
  
  mutate(
    
    Pixel = 1:n()
    
  ) |>
  
  pivot_longer(
    
    cols = -Pixel,
    
    names_to = "Method",
    
    values_to = "Suitability"
    
  )

################################################################################
## Friedman test
################################################################################

FriedmanResult <-
  
  friedman_test(
    
    SuitabilityLong,
    
    Suitability ~ Method | Pixel
    
  )

################################################################################
## Kendall's W
################################################################################

KendallResult <-
  
  friedman_effsize(
    
    SuitabilityLong,
    
    Suitability ~ Method | Pixel
    
  )

################################################################################
## Pairwise paired Wilcoxon
################################################################################

PairwiseResult <-
  
  pairwise_wilcox_test(
    
    SuitabilityLong,
    
    Suitability ~ Method,
    
    paired = TRUE,
    
    p.adjust.method = "holm"
    
  )

################################################################################
## Intraclass Correlation
################################################################################

ICCResult <-
  
  irr::icc(
    
    SuitabilityMatrix,
    
    model = "twoway",
    
    type = "agreement",
    
    unit = "single"
    
  )

################################################################################
## Summary
################################################################################

AgreementSummary <-
  
  data.frame(
    
    Friedman_ChiSquare = FriedmanResult$statistic,
    
    DF = FriedmanResult$df,
    
    P_value = FriedmanResult$p,
    
    Kendalls_W = KendallResult$effsize,
    
    ICC = ICCResult$value,
    
    ICC_Lower95 = ICCResult$lbound,
    
    ICC_Upper95 = ICCResult$ubound
    
  )

################################################################################
## Save outputs
################################################################################

write.csv(
  
  AgreementSummary,
  
  file.path(
    
    evaluation_dir,
    
    "AgreementSummary.csv"
    
  ),
  
  row.names = FALSE
  
)

write.csv(
  
  PairwiseResult,
  
  file.path(
    
    evaluation_dir,
    
    "PairwiseWilcoxon.csv"
    
  ),
  
  row.names = FALSE
  
)

capture.output(
  
  FriedmanResult,
  
  file = file.path(
    
    evaluation_dir,
    
    "Friedman_Test.txt"
    
  )
  
)

capture.output(
  
  ICCResult,
  
  file = file.path(
    
    evaluation_dir,
    
    "ICC.txt"
    
  )
  
)

cat("\n")
cat("Agreement analysis completed.\n")
