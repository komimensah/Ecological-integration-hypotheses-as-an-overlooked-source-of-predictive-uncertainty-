# ============================================================
# GDEX d314000: yearly daily downloads + preprocessing
# East cost fever domain
#
# ============================================================

library(glue)
library(terra)

options(timeout = 3600)

# ------------------------------------------------------------
# 1. Settings
# ------------------------------------------------------------

out_dir <- "GDEX_d314000_ECF_daily_1981_2008"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

bbox <- list(
  west  = 20,
  east  = 52,
  south = -20,
  north = 18
)

years <- 1981:2008
vars  <- c("tas", "shum", "pres")

safe_rotate <- function(r) {
  
  e <- terra::ext(r)
  
  # If already normal lon/lat, return unchanged
  if (e[1] >= -180 && e[2] <= 180) {
    return(r)
  }
  
  # If longitude is 0–360 or crosses beyond 360, shift x coordinates
  x <- terra::xFromCol(r, 1:terra::ncol(r))
  x_new <- ifelse(x > 180, x - 360, x)
  
  # Reassign extent using shifted longitude range
  terra::ext(r) <- terra::ext(
    min(x_new) - terra::res(r)[1] / 2,
    max(x_new) + terra::res(r)[1] / 2,
    e[3],
    e[4]
  )
  
  return(r)
}
# ------------------------------------------------------------
# 2. Download one full year of daily data
# ------------------------------------------------------------

download_gdex_year <- function(var, year, bbox, out_dir) {
  
  base_url <- glue(
    "https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d314000/daily/",
    "{var}_daily_{year}-{year}.nc"
  )
  
  request_url <- glue(
    "{base_url}?",
    "var={var}",
    "&north={bbox$north}",
    "&south={bbox$south}",
    "&east={bbox$east}",
    "&west={bbox$west}",
    "&horizStride=1",
    "&time_start={year}-01-01T00:00:00Z",
    "&time_end={year}-12-31T00:00:00Z",
    "&timeStride=1",
    "&accept=netcdf3"
  )
  
  out_file <- file.path(out_dir, glue("{var}_ECF_daily_{year}.nc"))
  
  if (file.exists(out_file)) {
    message("Already exists: ", out_file)
    return(out_file)
  }
  
  message("Downloading ", var, " for ", year)
  
  tryCatch({
    download.file(
      url = request_url,
      destfile = out_file,
      method = "libcurl",
      mode = "wb",
      quiet = FALSE
    )
    return(out_file)
  }, error = function(e) {
    message("FAILED: ", var, " ", year)
    message(e$message)
    return(NA)
  })
}

# ------------------------------------------------------------
# 3. Download tas, shum, pres for all years
# ------------------------------------------------------------

download_log <- data.frame()

for (yr in years) {
  for (v in vars) {
    
    f <- download_gdex_year(
      var = v,
      year = yr,
      bbox = bbox,
      out_dir = out_dir
    )
    
    download_log <- rbind(
      download_log,
      data.frame(
        variable = v,
        year = yr,
        file = f,
        success = !is.na(f) && file.exists(f)
      )
    )
  }
}

write.csv(
  download_log,
  file.path(out_dir, "download_log.csv"),
  row.names = FALSE
)

# ------------------------------------------------------------
# 4. Compute and save daily Temperature (°C) and Relative Humidity (%)
# ------------------------------------------------------------

processed_dir <- file.path(out_dir, "processed_T_RH")
dir.create(processed_dir, showWarnings = FALSE, recursive = TRUE)

process_gdex_year <- function(yr, out_dir, processed_dir) {
  
  message("Processing year: ", yr)
  
  tas_file  <- file.path(out_dir, glue("tas_ECF_daily_{yr}.nc"))
  shum_file <- file.path(out_dir, glue("shum_ECF_daily_{yr}.nc"))
  pres_file <- file.path(out_dir, glue("pres_ECF_daily_{yr}.nc"))
  
  if (!file.exists(tas_file) ||
      !file.exists(shum_file) ||
      !file.exists(pres_file)) {
    
    warning("Missing one or more files for year: ", yr)
    return(NULL)
    
  }
  
  tas  <- safe_rotate(rast(tas_file))
  shum <- safe_rotate(rast(shum_file))
  pres <- safe_rotate(rast(pres_file))
  
  #----------------------------------------------------------
  # Unit conversions
  #----------------------------------------------------------
  
  T_c   <- tas - 273.15
  P_hPa <- pres / 100
  q     <- shum
  
  #----------------------------------------------------------
  # Saturation vapour pressure (hPa)
  #----------------------------------------------------------
  
  es <- 6.112 * exp((17.67 * T_c) / (T_c + 243.5))
  
  #----------------------------------------------------------
  # Actual vapour pressure (hPa)
  #----------------------------------------------------------
  
  ea <- (q * P_hPa) / (0.622 + 0.378 * q)
  
  
  #----------------------------------------------------------
  # Relative humidity (%)
  #----------------------------------------------------------
  
  RH <- 100 * ea / es
  
  # Keep RH within physical limits
  RH[RH < 0]   <- 0
  RH[RH > 100] <- 100
  #----------------------------------------------------------
  # Layer names
  #----------------------------------------------------------
  
  names(T_c) <- paste0("T_C_", yr, "_", 1:nlyr(T_c))
  names(RH)  <- paste0("RH_", yr, "_", 1:nlyr(RH))
  
  #----------------------------------------------------------
  # Output files
  #----------------------------------------------------------
  
  T_out  <- file.path(
    processed_dir,
    glue("Temperature_C_ECF_daily_{yr}.nc")
  )
  
  RH_out <- file.path(
    processed_dir,
    glue("RelativeHumidity_ECF_daily_{yr}.nc")
  )
  
  #----------------------------------------------------------
  # Save outputs
  #----------------------------------------------------------
  
  writeCDF(
    T_c,
    filename = T_out,
    varname = "temperature",
    unit = "degC",
    overwrite = TRUE
  )
  
  writeCDF(
    RH,
    filename = RH_out,
    varname = "RH",
    unit = "%",
    overwrite = TRUE
  )
  
  message("Saved: ", T_out)
  message("Saved: ", RH_out)
  
  return(
    data.frame(
      year = yr,
      temperature_file = T_out,
      rh_file = RH_out
    )
  )
  
}

processed_log <- do.call(
  rbind,
  lapply(
    years,
    process_gdex_year,
    out_dir = out_dir,
    processed_dir = processed_dir
  )
)

write.csv(
  processed_log,
  file.path(processed_dir, "processed_T_RH_log.csv"),
  row.names = FALSE
)
# ------------------------------------------------------------
# 5. Quick check
# ------------------------------------------------------------

test_T <- rast(
  file.path(
    processed_dir,
    "Temperature_C_ECF_daily_1981.nc"
  )
)

test_RH <- rast(
  file.path(
    processed_dir,
    "RelativeHumidity_ECF_daily_1981.nc"
  )
)

plot(test_T[[1]],
     main = "Temperature (°C), 1 Jan 1981")

plot(test_RH[[1]],
     main = "Relative Humidity (%), 1 Jan 1981")
