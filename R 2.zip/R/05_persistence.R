###############################################################
# Tick Persistence Framework
# File        : 05_persistence.R
# Purpose     : Mechanistic persistence index (Rv)
###############################################################

if (!exists("params")) {
  stop("Run 01_parameters.R first.")
}


###############################################################
## Host-finding probability
##
## H = normalized host density (0–1)
## Maximum encounter rate from Short et al. (1989)
###############################################################

Qh <- function(H){
  
  beta <- 1 / 20
  
  1 - exp(-beta * H)
  
}
###############################################################
## Safe transition probability
###############################################################

transition_probability <- function(G, M){
  
  if(G <= 0){
    
    return(0)
    
  }
  
  G / (G + M)
  
}
###############################################################
## Persistence index
###############################################################

Persistence <- function(
    T,
    RH,
    H=1,
    n = 1,
    fecundity_pars = NULL,
    questing_pars = NULL){
  
  ## Reproductive output
  ## Reproductive output
  F <- compute_F(
    n = n,
    pars = fecundity_pars
  )
  
  ## Development rates
  GE <- G_E(T)
  GL <- G_L(T)
  GN <- G_N(T)
  GA <- G_A(T)
  
  ## Mortality
  ME <- M_E(T, RH)
  ML <- M_L(T, RH)
  MN <- M_N(T)
  MA <- M_A(T)
  
  ## Questing mortality
  ## Questing mortality
  MQL <- M_QuestLarva(
    n = n,
    pars = questing_pars
  )
  
  MQN <- M_QuestNymph(
    n = n,
    pars = questing_pars
  )
  
  MQA <- M_QuestAdult(
    n = n,
    pars = questing_pars
  )
  
  ## Constant host-acquisition rate
  qh <- Qh(H)
  
  ## Stage transition probabilities
  
  
  PE  <- transition_probability(GE, ME)
  
  PQL <- transition_probability(qh, MQL)
  
  PL  <- transition_probability(GL, ML)
  
  PQN <- transition_probability(qh, MQN)
  
  PN  <- transition_probability(GN, MN)
  
  PQA <- transition_probability(qh, MQA)
  
  PA  <- transition_probability(GA, MA)
  
  ## Persistence index
  RV <-
    F *
    PE *
    PQL *
    PL *
    PQN *
    PN *
    PQA *
    PA
  
  data.frame(
    Temperature = T,
    RH = RH,
    F = F,
    Egg = PE,
    QuestLarva = PQL,
    Larva = PL,
    QuestNymph = PQN,
    Nymph = PN,
    QuestAdult = PQA,
    Adult = PA,
    Persistence = RV
  )
}
###############################################################
## Fast persistence engine
## Returns only the persistence index (RV)
## Used for daily climate simulations
###############################################################

Persistence_RV <- function(
    T,
    RH,
    H=1,
    n = 1,
    fecundity_pars = NULL,
    questing_pars = NULL
){
  
  ## Reproductive output
  F <- compute_F(
    n = n,
    pars = fecundity_pars
  )
  
  ## Development
  GE <- G_E(T)
  GL <- G_L(T)
  GN <- G_N(T)
  GA <- G_A(T)
  
  ## Mortality
  ME <- M_E(T, RH)
  ML <- M_L(T, RH)
  MN <- M_N(T)
  MA <- M_A(T)
  
  ## Questing mortality
  MQL <- M_QuestLarva(
    n = n,
    pars = questing_pars
  )
  
  MQN <- M_QuestNymph(
    n = n,
    pars = questing_pars
  )
  
  MQA <- M_QuestAdult(
    n = n,
    pars = questing_pars
  )
  
  ## Host-dependent acquisition probability
  qh <- Qh(H)
  
  ## Transition probabilities
  PE  <- transition_probability(GE, ME)
  
  PQL <- transition_probability(qh, MQL)
  
  PL  <- transition_probability(GL, ML)
  
  PQN <- transition_probability(qh, MQN)
  
  PN  <- transition_probability(GN, MN)
  
  PQA <- transition_probability(qh, MQA)
  
  PA  <- transition_probability(GA, MA)
  
  ## Mechanistic persistence index
  RV <-
    F *
    PE *
    PQL *
    PL *
    PQN *
    PN *
    PQA *
    PA
  
  return(RV)
  
}