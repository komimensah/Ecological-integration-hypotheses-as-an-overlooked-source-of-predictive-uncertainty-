###############################################################
# Tick Persistence Framework
# File        : 08_figures.R
# Purpose     : Publication-quality figures
###############################################################

library(ggplot2)
library(dplyr)
library(tidyr)

###############################################################
## Figure 1 - Development rates
###############################################################

PlotDevelopment <- function(){
  
  T <- seq(10, 40, by = 0.25)
  
  dev <- data.frame(
    Temperature = T,
    Egg    = G_E(T),
    Larva  = G_L(T),
    Nymph  = G_N(T),
    Adult  = G_A(T)
  )
  
  dev <- pivot_longer(
    dev,
    cols = -Temperature,
    names_to = "Stage",
    values_to = "Rate"
  )
  
  ggplot(dev,
         aes(x = Temperature,
             y = Rate,
             colour = Stage)) +
    geom_line(linewidth = 1.2) +
    theme_classic(base_size = 14) +
    labs(
      x = "Temperature (°C)",
      y = "Development rate (day⁻¹)"
    )
  
}

###############################################################
## Figure 2 - Stage survival
###############################################################

PlotSurvival <- function(T = 25){
  
  RH <- seq(40, 100, by = 1)
  
  surv <- data.frame(
    RH = RH,
    Egg    = stage_probability("egg", RH),
    Larva  = stage_probability("larva", RH),
    Nymph  = stage_probability("nymph", RH),
    Adult  = stage_probability("adult", RH)
  )
  
  surv <- pivot_longer(
    surv,
    cols = -RH,
    names_to = "Stage",
    values_to = "Survival"
  )
  
  ggplot(
    surv,
    aes(
      x = RH,
      y = Survival,
      colour = Stage
    )
  ) +
    geom_line(linewidth = 1.2) +
    theme_classic(base_size = 14) +
    labs(
      x = "Relative humidity (%)",
      y = "Stage survival probability"
    )
  
}
###############################################################
## Figure 3 - Persistence surface
###############################################################

PlotPersistence <- function(){
  
  T  <- seq(10, 40, by = 0.25)
  RH <- seq(40,100, by = 0.5)
  
  grid <- expand.grid(
    Temperature = T,
    RH = RH
  )
  
  grid$Persistence <- mapply(
    
    function(temp, rh){
      
      Persistence(
        T  = temp,
        RH = rh
      )$Persistence
      
    },
    
    grid$Temperature,
    grid$RH
    
  )
  
  ggplot(
    grid,
    aes(
      x = Temperature,
      y = RH,
      fill = Persistence
    )
  ) +
    
    ## smoother than geom_tile()
    geom_raster(interpolate = TRUE) +
    
    ## highlight persistence threshold
    geom_contour(
      aes(z = Persistence),
      breaks = 1,
      colour = "white",
      linewidth = 0.6
    ) +
    
    scale_fill_viridis_c(
      option = "C",
      name = expression(lambda)
    ) +
    
    coord_cartesian(
      xlim = c(10,40),
      ylim = c(40,100),
      expand = FALSE
    ) +
    
    theme_classic(base_size = 16) +
    
    theme(
      
      legend.title = element_text(face = "bold"),
      
      axis.title = element_text(face = "bold"),
      
      axis.text = element_text(colour = "black")
      
    ) +
    
    labs(
      
      x = expression("Temperature ("*degree*C*")"),
      
      y = "Relative humidity (%)"
      
    )
  
}
###############################################################
## Figure 4 - Uncertainty surface
###############################################################

PlotUncertainty <- function(nsim = 1000){
  
  T  <- seq(10,40,by=1)
  RH <- seq(40,100,by=2)
  
  grid <- expand.grid(
    
    Temperature = T,
    
    RH = RH
    
  )
  
  grid$SD <- mapply(
    
    function(temp, rh){
      
      out <- TemperatureProfile(
        
        T = temp,
        
        RH = rh,
        
        nsim = nsim
        
      )
      
      out$SD
      
    },
    
    grid$Temperature,
    
    grid$RH
    
  )
  
  ggplot(
    
    grid,
    
    aes(
      
      x = Temperature,
      
      y = RH,
      
      fill = SD
      
    )
    
  ) +
    
    geom_tile() +
    
    scale_fill_viridis_c(
      
      option = "C",
      
      name = "SD"
      
    ) +
    
    theme_classic(base_size = 14) +
    
    labs(
      
      x = "Temperature (°C)",
      
      y = "Relative humidity (%)"
      
    )
  
}
###############################################################
## Save all figures
###############################################################

SaveFigures <- function(){
  
  ggsave(
    filename = "Figure1_Development.png",
    plot = PlotDevelopment(),
    width = 7,
    height = 5,
    dpi = 600
  )
  
  ggsave(
    filename = "Figure2_Survival.png",
    plot = PlotSurvival(),
    width = 7,
    height = 5,
    dpi = 600
  )
  
  ggsave(
    filename = "Figure3_Persistence.png",
    plot = PlotPersistence(),
    width = 7,
    height = 5,
    dpi = 600
  )
  
  ggsave(
    filename = "Figure4_Uncertainty.png",
    plot = PlotUncertainty(),
    width = 7,
    height = 5,
    dpi = 600
  )
  
}

###############################################################
## Create all figures
###############################################################

SaveFigures()