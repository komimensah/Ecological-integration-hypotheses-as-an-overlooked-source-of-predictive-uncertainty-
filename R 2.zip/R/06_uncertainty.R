###############################################################
# Tick Persistence Framework
# File        : 06_uncertainty.R
# Purpose     : Monte Carlo uncertainty analysis
###############################################################

if (!exists("params")) {
  stop("Run 01_parameters.R first.")
}


###############################################################
## One Monte Carlo simulation
###############################################################

run_once <- function(T, RH){
  
  Persistence(T = T, RH = RH)$Persistence
  
}


###############################################################
## Monte Carlo uncertainty
###############################################################

MonteCarloPersistence <- function(
    T,
    RH,
    nsim = 1000){
  
  results <- replicate(
    
    nsim,
    
    run_once(T, RH)
    
  )
  
  summary <- data.frame(
    
    Mean     = mean(results),
    Median   = median(results),
    SD       = sd(results),
    CV       = sd(results) / mean(results),
    Minimum  = min(results),
    Maximum  = max(results),
    Lower95  = quantile(results, 0.025),
    Upper95  = quantile(results, 0.975),
    Probability = mean(results >= 1)
    
  )
  
  list(
    
    simulations = results,
    
    summary = summary
    
  )
  
}


###############################################################
## Temperature profile
###############################################################

TemperatureProfile <- function(
    T,
    RH,
    nsim = 1000){
  
  ## Matrix to store all simulations
  sims <- matrix(
    NA,
    nrow = length(T),
    ncol = nsim
  )
  
  ## Bootstrap loop (outer loop)
  for(i in 1:nsim){
    
    ## Draw one bootstrap parameter set
    fecundity_pars <- draw_fecundity_parameters(1)
    
    questing_pars <- draw_questing_parameters(1)
    
    ## Temperature loop (inner loop)
    sims[, i] <- sapply(
      T,
      function(x){
        
        Persistence(
          T = x,
          RH = RH,
          fecundity_pars = fecundity_pars,
          questing_pars = questing_pars
        )$Persistence
        
      }
      
    )
    
  }
  
  ## Summarise uncertainty at each temperature
  data.frame(
    
    Temperature = T,
    
    Mean = apply(sims, 1, mean),
    
    Median = apply(sims, 1, median),
    
    SD = apply(sims, 1, sd),
    
    CV = apply(sims, 1, function(z) sd(z)/mean(z)),
    
    Minimum = apply(sims, 1, min),
    
    Maximum = apply(sims, 1, max),
    
    Lower95 = apply(sims, 1, quantile, probs = 0.025),
    
    Upper95 = apply(sims, 1, quantile, probs = 0.975),
    
    Probability = apply(sims, 1, function(z) mean(z >= 1))
    
  )
  
}
###############################################################
## Humidity profile
###############################################################

HumidityProfile <- function(
    RH,
    T,
    nsim = 1000){
  
  out <- lapply(
    
    RH,
    
    function(x){
      
      tmp <- MonteCarloPersistence(
        
        T = T,
        RH = x,
        nsim = nsim
        
      )
      
      cbind(
        
        RH = x,
        
        tmp$summary
        
      )
      
    }
    
  )
  
  do.call(rbind, out)
  
}