#===========================================================
# 11_ECF_Integration_Pathways.R
# Mechanistic integration operators
#===========================================================

#-----------------------------------------------------------
# Branching process transformation
# Converts tick persistence index (R_tick)
# into persistence probability (P_tick)
#-----------------------------------------------------------

branching_probability <- function(R_tick){
  
  ifelse(
    R_tick <= 1,
    0,
    1 - (1 / R_tick)
  )
  
}

#===========================================================
# Integration pathway 1
# Multiplicative
#===========================================================

integration_multiplicative <- function(
    P_tick,
    P_parasite
){
  
  P_tick * P_parasite
  
}

#===========================================================
# Integration pathway 2
# Limiting factor
#===========================================================

integration_limiting <- function(
    P_tick,
    P_parasite
){
  
  pmin(P_tick, P_parasite)
  
}

#===========================================================
# Integration pathway 3
# Arithmetic mean
#===========================================================

integration_arithmetic <- function(
    P_tick,
    P_parasite
){
  
  (P_tick + P_parasite) / 2
  
}

#===========================================================
# Integration pathway 4
# Geometric mean
#===========================================================

integration_geometric <- function(
    P_tick,
    P_parasite
){
  
  sqrt(P_tick * P_parasite)
  
}

#===========================================================
# Integration pathway 5
# Weighted integration
#===========================================================

integration_weighted <- function(
    P_tick,
    P_parasite,
    weight
){
  
  if(weight < 0 | weight > 1){
    
    stop("weight must be between 0 and 1.")
    
  }
  
  weight * P_tick +
    (1 - weight) * P_parasite
  
}
#===========================================================
# Integration pathway 6
# Fuzzy integration
#===========================================================

integration_fuzzy <- function(
    P_tick,
    P_parasite
){
  
  out <- numeric(length(P_tick))
  
  for(i in seq_along(P_tick)){
    
    if(P_tick[i] >= 0.70 & P_parasite[i] >= 0.70){
      
      out[i] <- 1.00
      
    } else if(P_tick[i] >= 0.70 & P_parasite[i] >= 0.40){
      
      out[i] <- 0.80
      
    } else if(P_tick[i] >= 0.40 & P_parasite[i] >= 0.70){
      
      out[i] <- 0.80
      
    } else if(P_tick[i] >= 0.40 & P_parasite[i] >= 0.40){
      
      out[i] <- 0.60
      
    } else if(P_tick[i] >= 0.20 | P_parasite[i] >= 0.20){
      
      out[i] <- 0.30
      
    } else{
      
      out[i] <- 0
      
    }
    
  }
  
  out
  
}