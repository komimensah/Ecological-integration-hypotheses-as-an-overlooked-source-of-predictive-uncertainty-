#===========================================================
# 11. Tick-to-host transmission probability (P_VH)
#===========================================================

library(minpack.lm)
library(MASS)
library(tidyverse)

#-----------------------------------------------------------
# 11.1 Data
#-----------------------------------------------------------
acini <- data.frame(
  Temp  = c(18,23,28,37),
  Acini = c(0.56,23,16.2,4.09)
)

Amax <- 23
beta <- log(2)/0.56      # = 1.238

#-----------------------------------------------------------
# 11.2 Fit constrained quadratic model
#-----------------------------------------------------------

fit_fun <- function(dat){
  
  fit <- nls(
    Acini ~ Amax - k*(Temp - Topt)^2,
    data = dat,
    start = list(Topt = 26,
                 k = 0.20),
    algorithm = "port",
    lower = c(15,0),
    upper = c(40,5)
  )
  
  coef(fit)
  
}

par_est <- fit_fun(acini)

print(par_est)

#-----------------------------------------------------------
# 11.3 Parametric bootstrap parameter uncertainty
#-----------------------------------------------------------

set.seed(123)

B <- 5000

Tgrid <- seq(15,40,length.out=300)

boot_pred <- matrix(
  NA,
  nrow = length(Tgrid),
  ncol = B
)

boot_par <- matrix(
  NA,
  nrow = B,
  ncol = 2
)

colnames(boot_par) <- c("Topt","k")

## Approximate measurement uncertainty (10% CV)
## Replace these values with published SDs if available.
acini_sd <- c(
  0.10,
  2.30,
  1.62,
  0.41
)

for(i in 1:B){
  
  samp <- acini
  
  ## Keep temperatures fixed and perturb only the observations
  samp$Acini <- rnorm(
    nrow(acini),
    mean = acini$Acini,
    sd   = acini_sd
  )
  
  samp$Acini <- pmax(0, samp$Acini)
  
  fit <- try(
    fit_fun(samp),
    silent = TRUE
  )
  
  if(!inherits(fit,"try-error")){
    
    boot_par[i,] <- fit
    
    boot_pred[,i] <-
      pmax(
        0,
        Amax -
          fit["k"] *
          (Tgrid-fit["Topt"])^2
      )
    
  }
  
}

boot_par  <- na.omit(boot_par)
boot_pred <- boot_pred[,colSums(is.na(boot_pred))==0]

#-----------------------------------------------------------
# 11.4 Bootstrap confidence bands
#-----------------------------------------------------------

Acini_mean <-
  pmax(
    0,
    Amax -
      par_est["k"] *
      (Tgrid-par_est["Topt"])^2
  )

Acini_CI <- data.frame(
  
  Temp = Tgrid,
  
  Mean = Acini_mean,
  
  Lower = apply(boot_pred,1,quantile,0.025),
  
  Upper = apply(boot_pred,1,quantile,0.975)
  
)

summary(boot_par)

#-----------------------------------------------------------
# 11.4 Transmission probability (Hill function)
#-----------------------------------------------------------

K <- 0.56      # 50% transmission
n <- 2         # Hill coefficient (adjust later if needed)

PVH_boot <- (boot_pred^n)/(K^n + boot_pred^n)

PVH_CI <- data.frame(
  Temp  = Tgrid,
  Mean  = apply(PVH_boot,1,median),
  Lower = apply(PVH_boot,1,quantile,0.025),
  Upper = apply(PVH_boot,1,quantile,0.975)
)


#-----------------------------------------------------------
# 11.5 Parasite maturation probability
#-----------------------------------------------------------

pu_dat <- data.frame(
  Temp = c(18,23,28,33,37),
  Mean = c(0.0050,0.4867,0.4467,0.0517,0.0017),
  SD   = c(0.0122,0.1625,0.1308,0.0674,0.0041)
)

Afix <- max(pu_dat$Mean)

fit_fun_pu <- function(dat){
  
  fit <- nls(
    Mean ~ Afix * exp(-(Temp - Topt)^2/(2*sigma^2)),
    data = dat,
    start = list(
      Topt = 25,
      sigma = 3
    ),
    algorithm = "port",
    lower = c(18,1),
    upper = c(35,8)
  )
  
  coef(fit)
  
}

set.seed(123)

PU_boot <- matrix(
  NA,
  nrow = length(Tgrid),
  ncol = B
)

boot_par_pu <- matrix(
  NA,
  nrow = B,
  ncol = 2
)

colnames(boot_par_pu) <- c("Topt","sigma")

for(i in 1:B){
  
  samp <- pu_dat
  
  samp$Mean <- rnorm(
    nrow(pu_dat),
    pu_dat$Mean,
    pu_dat$SD
  )
  
  samp$Mean <- pmin(
    Afix,
    pmax(0,samp$Mean)
  )
  
  fit <- try(
    fit_fun_pu(samp),
    silent = TRUE
  )
  
  if(!inherits(fit,"try-error")){
    
    boot_par_pu[i,] <- fit
    
    PU_boot[,i] <-
      Afix *
      exp(
        -(Tgrid-fit["Topt"])^2 /
          (2*fit["sigma"]^2)
      )
    
  }
  
}

PU_boot <- PU_boot[,
                   colSums(is.na(PU_boot))==0]

PU_CI <- data.frame(
  
  Temp = Tgrid,
  
  Mean = apply(PU_boot,1,median),
  
  Lower = apply(PU_boot,1,quantile,0.025),
  
  Upper = apply(PU_boot,1,quantile,0.975)
  
)
#-----------------------------------------------------------
# 11.6 Persistence index
#-----------------------------------------------------------

#-----------------------------------------------------------
# 11.6 Persistence index
#-----------------------------------------------------------

nboot <- min(ncol(PVH_boot), ncol(PU_boot))

RP_boot <- sqrt(
  0.708 *
    PVH_boot[,1:nboot] *
    PU_boot[,1:nboot]
)

RP_CI <- data.frame(
  Temp  = Tgrid,
  Mean  = rowMeans(RP_boot),
  Lower = apply(RP_boot,1,quantile,0.025),
  Upper = apply(RP_boot,1,quantile,0.975)
)

#===========================================================
# 11.7 Plot pathogen persistence index
#===========================================================

Figure_RP <-
  
  ggplot(
    RP_CI,
    aes(
      x = Temp,
      y = Mean
    )
  ) +
  
  geom_ribbon(
    aes(
      ymin = Lower,
      ymax = Upper
    ),
    fill = "grey80",
    alpha = 0.6
  ) +
  
  geom_line(
    colour = "#C51B7D",
    linewidth = 1.4
  ) +
  
  coord_cartesian(
    xlim = c(15,40),
    ylim = c(0,1)
  ) +
  
  scale_x_continuous(
    breaks = seq(15,40,5)
  ) +
  
  scale_y_continuous(
    breaks = seq(0,1,0.2)
  ) +
  
  labs(
    x = expression("Temperature ("*degree*C*")"),
    y = expression(R[P](T))
  ) +
  
  theme_classic(base_size = 15) +
  
  theme(
    
    axis.title = element_text(
      face = "bold"
    ),
    
    axis.text = element_text(
      colour = "black"
    )
    
  )

############################################################
# Print
############################################################

print(Figure_RP)

############################################################
# Save
############################################################

ggsave(
  "Figure_PathogenPersistence.png",
  Figure_RP,
  width = 7,
  height = 5,
  dpi = 600,
  bg = "white"
)

ggsave(
  "Figure_PathogenPersistence.pdf",
  Figure_RP,
  width = 7,
  height = 5,
  bg = "white"
)
getwd()
