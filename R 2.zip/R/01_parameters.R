###############################################################
# Tick Persistence Framework
# File        : 01_parameters.R
# Purpose     : Biological parameters extracted from the
#               experimental literature.
#
# IMPORTANT
# ----------
# This file contains NO equations.
# This file contains NO simulations.
# This file contains NO plotting.
#
# Every numerical value used in the model should originate
# from this file.
###############################################################

###############################################################
## Species information
###############################################################

species <- list(
  
  scientific_name = "Rhipicephalus appendiculatus",
  
  common_name = "Brown Ear Tick",
  
  sex_ratio = 0.50
  
)



###############################################################
## Development parameters
##
## Source:
## Tukahirwa (1976)
###############################################################

development = list(
  
  egg = list(
    slope = 0.151,
    intercept = 7.3,
    Tmin = 16,
    Topt = 30,
    Tmax = 34,
    alpha = 2.0,
    beta  = 2.8
  ),
  
  larva = list(
    slope = 0.444,
    intercept = 9.2,
    Tmin = 12,
    Topt = 34,
    Tmax = 41,
    alpha = 2.2,
    beta  = 2.0
  ),
  
  nymph = list(
    slope = 0.316,
    intercept = 11.5,
    Tmin = 12,
    Topt = 38,
    Tmax = 41,
    alpha = 2.3,
    beta  = 1.6
  ),
  
  adult = list(
    slope = 0.654,
    intercept = 8.9,
    Tmin = 9,
    Topt = 34,
    Tmax = 41,
    alpha = 2.0,
    beta  = 2.0
  )
  
)

###############################################################
## Egg hatch logistic model
##
## Derived from Tukahirwa observations
###############################################################

egg_hatch <- list(
  
  beta0 = 43.873,
  
  beta1 = -0.5986
  
)



###############################################################
## Larval moulting logistic model
##
## Derived from Tukahirwa observations
###############################################################

larval_moult <- list(
  
  beta0 = 3.352,
  
  beta1 = -0.06834
  
)



###############################################################
## Nymph moulting
##
## Little RH effect
###############################################################

nymph_moult <- list(
  
  survival = 0.9025
  
)



###############################################################
## Female survival
##
## Short et al.
###############################################################

female_survival <- list(
  
  survival = 0.9883
  
)



###############################################################
## Bootstrap datasets
##
## Values extracted directly from the experimental papers.
###############################################################

bootstrap <- list()



###############################################################
## Questing larvae
##
## Median survival times (days)
##
## Short et al.
###############################################################

bootstrap$quest_larva <- c(
  
  35,
  143,
  67,
  39,
  84,
  50,
  91,
  22,
  59,
  56,
  33,
  63
  
)



###############################################################
## Questing nymphs
##
## TO BE VERIFIED AGAIN FROM TABLE 3
###############################################################

bootstrap$quest_nymph <- c(
  
  # Long grass: laboratory-moulted
  
  62,
  
  158,
  
  85,
  
  # Long grass: field-moulted
  
  79,
  
  81,
  
  84,
  
  # Short grass: laboratory-moulted
  
  38,
  
  54,
  
  67,
  
  # Short grass: field-moulted
  
  57,
  
  63,
  
  63
  
)



###############################################################
## Questing adults
##
## TO BE VERIFIED AGAIN FROM TABLE 4
###############################################################

bootstrap$quest_adult <- c(
  
  # Long grass: laboratory-moulted
  
  333,
  
  493,
  
  438,
  
  # Long grass: field-moulted
  
  228,
  
  234,
  
  424,
  
  # Short grass: laboratory-moulted
  
  229,
  
  165,
  
  375,
  
  # Short grass: field-moulted
  
  127,
  
  95,
  
  346
  
)

###############################################################
## Eggs produced per female
##
## Short et al.
###############################################################

bootstrap$fecundity <- c(
  
  4490,
  4856,
  1392,
  1614,
  5778,
  2559,
  5504,
  5655
  
)



###############################################################
## Egg hatch (%)
##
## Short et al.
###############################################################

bootstrap$egg_hatch <- c(
  
  22,
  60,
  87,
  55,
  95,
  96,
  8,
  60,
  85,
  16,
  78,
  69,
  69,
  94,
  70,
  94,
  97,
  91
  
)



###############################################################
## Combine everything
###############################################################

params <- list(
  
  species = species,
  
  development = development,
  
  egg_hatch = egg_hatch,
  
  larval_moult = larval_moult,
  
  nymph_moult = nymph_moult,
  
  female_survival = female_survival,
  
  bootstrap = bootstrap
  
)



###############################################################
## Save
###############################################################
dir.create("data", showWarnings = FALSE)
dir.create("R", showWarnings = FALSE)
dir.create("output", showWarnings = FALSE)
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)
dir.create("output/tables", recursive = TRUE, showWarnings = FALSE)
dir.create("output/validation", recursive = TRUE, showWarnings = FALSE)
save(
  
  params,
  
  file = "data/parameters.RData"
  
)

