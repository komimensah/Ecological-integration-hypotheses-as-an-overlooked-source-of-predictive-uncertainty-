###############################################################
# Script 13
# Daily mechanistic suitability modelling
#
# East Coast Fever Framework
#
# Purpose
# -------
# 1. Read daily temperature and RH
# 2. Compute tick persistence
# 3. Compute pathogen suitability
# 4. Integrate both components
# 5. Export daily annual NetCDF products
#
###############################################################

rm(list = ls())

graphics.off()

cat("\014")

###############################################################
## Packages
###############################################################

library(terra)
library(parallel)
library(glue)
library(lubridate)
setwd('/Users/kagboka/Desktop/R.appendi/')
###############################################################
## Directories
###############################################################

climate_dir <-
  "GDEX_d314000_ECF_daily_1981_2008/processed_T_RH"

output_dir <-
  "ECF_Daily_Suitability"

dir.create(
  output_dir,
  recursive=TRUE,
  showWarnings=FALSE
)

dir.create(
  file.path(output_dir,"Tick"),
  recursive=TRUE,
  showWarnings=FALSE
)

dir.create(
  file.path(output_dir,"Pathogen"),
  recursive=TRUE,
  showWarnings=FALSE
)

dir.create(
  file.path(output_dir,"Integrated"),
  recursive=TRUE,
  showWarnings=FALSE
)

dir.create(
  file.path(output_dir,"Logs"),
  recursive=TRUE,
  showWarnings=FALSE
)

dir.create(
  file.path(output_dir,"Temp"),
  recursive=TRUE,
  showWarnings=FALSE
)

###############################################################
## Years
###############################################################

years <- 1981:2008

###############################################################
## General options
###############################################################

overwrite <- TRUE

resume <- TRUE

###############################################################
## Weighted integration sensitivity
###############################################################

tick_weights <- seq(0.1, 0.9, by = 0.1)

###############################################################
## Terra options
###############################################################

terraOptions(
  
  memfrac=0.70,
  
  tempdir=file.path(output_dir,"Temp"),
  
  progress=1
  
)

###############################################################
## Parallel
###############################################################

ncores <- 1
###############################################################
## Source scripts
###############################################################

source("R/01_parameters.R")

source("R/02_development.R")

source("R/03_mortality.R")

source("R/04_fecundity.R")

source("R/05_persistence.R")

source("R/10_Pathogene_thermalreponses.R")

source("R/11_ECF_Integration_Pathways.R")
###############################################################
## Livestock density
###############################################################

HostDensity <- rast("/Users/kagboka/Desktop/R.appendi/cattle.tif")

## Reference climate raster
ReferenceRaster <- rast(
  file.path(
    climate_dir,
    "Temperature_C_ECF_daily_1981.nc"
  )
)[[1]]

## Same CRS
HostDensity <- project(
  HostDensity,
  ReferenceRaster,
  method = "bilinear"
)

## Same extent
HostDensity <- crop(
  HostDensity,
  ReferenceRaster
)

## Same resolution
HostDensity <- resample(
  HostDensity,
  ReferenceRaster,
  method = "bilinear"
)

## Same mask
HostDensity <- mask(
  HostDensity,
  ReferenceRaster
)

## Normalize
HostDensity <- HostDensity /
  global(
    HostDensity,
    "max",
    na.rm = TRUE
  )[1,1]
###############################################################
## Livestock density
###############################################################

HostDensity <- rast("/Users/kagboka/Desktop/R.appendi/cattle.tif")

## Reference climate raster
ReferenceRaster <- rast(
  file.path(
    climate_dir,
    "Temperature_C_ECF_daily_1981.nc"
  )
)[[1]]

## Same CRS
HostDensity <- project(
  HostDensity,
  ReferenceRaster,
  method = "bilinear"
)

## Same extent
HostDensity <- crop(
  HostDensity,
  ReferenceRaster
)

## Same resolution
HostDensity <- resample(
  HostDensity,
  ReferenceRaster,
  method = "bilinear"
)

## Same mask
HostDensity <- mask(
  HostDensity,
  ReferenceRaster
)

## Normalize
HostDensity <- HostDensity /
  global(
    HostDensity,
    "max",
    na.rm = TRUE
  )[1,1]
###############################################################
## Fixed fecundity parameters
###############################################################

set.seed(123)

fecundity_pars <- draw_fecundity_parameters(n = 1)
###############################################################
## Pathogen response
###############################################################

RP_CI <-
  RP_CI[
    order(RP_CI$Temp),
  ]

RP_CI$Mean <-
  pmax(
    0,
    pmin(
      1,
      RP_CI$Mean
    )
  )

PathogenSuitability <-
  approxfun(
    
    x=RP_CI$Temp,
    
    y=RP_CI$Mean,
    
    rule=2
    
  )
###############################################################
## Fast transition probability
###############################################################

transition_probability_fast <-
  function(G,M){
    
    P <- G/(G+M)
    
    P[G<=0] <- 0
    
    P[!is.finite(P)] <- NA
    
    P
    
  }
###############################################################
## Fast raster persistence engine
###############################################################

PersistenceRaster <- function(T, RH, H){
    
    ####################################################
    ## Fecundity
    ####################################################
    
    F <- compute_F(
      pars = fecundity_pars
    )
    ####################################################
    ## Development
    ####################################################
    
    GE <- G_E(T)
    
    GL <- G_L(T)
    
    GN <- G_N(T)
    
    GA <- G_A(T)
    
    ####################################################
    ## Mortality
    ####################################################
    
    ME <- M_E(T,RH)
    
    ML <- M_L(T,RH)
    
    MN <- M_N(T)
    
    MA <- M_A(T)
    
    ####################################################
    ## Questing mortality
    ####################################################
    
    MQL <- M_QuestLarva()
    
    MQN <- M_QuestNymph()
    
    MQA <- M_QuestAdult()
    
    ####################################################
    ## Host acquisition
    ####################################################
    
    qh <- Qh(H)
    
    ####################################################
    ## Transition probabilities
    ####################################################
    
    PE <-
      transition_probability_fast(GE,ME)
    
    PQL <-
      transition_probability_fast(qh,MQL)
    
    PL <-
      transition_probability_fast(GL,ML)
    
    PQN <-
      transition_probability_fast(qh,MQN)
    
    PN <-
      transition_probability_fast(GN,MN)
    
    PQA <-
      transition_probability_fast(qh,MQA)
    
    PA <-
      transition_probability_fast(GA,MA)
    
    ####################################################
    ## Persistence index
    ####################################################
    
    RV <-
      
      F*
      PE*
      PQL*
      PL*
      PQN*
      PN*
      PQA*
      PA
    
    RV <- pmax(
      0,
      RV
    )
    
    RV
    
  }
###############################################################
## Tick persistence probability
###############################################################

TickProbability <-
  function(R){
    
    P <- 1 - (1 / R)
    
    P[!is.finite(P)] <- 0
    
    P[R <= 1] <- 0
    
    P <- pmin(1, pmax(0, P))
    
    P
    
  }
###############################################################
## Metric names
###############################################################

metric_names <- c(
  
  "Tick",
  
  "Pathogen",
  
  "Multiplicative",
  
  "Limiting",
  
  "Arithmetic",
  
  "Geometric",
  
  paste0(
    "Weighted_",
    tick_weights * 100
  ),
  
  "Fuzzy"
  
)
###############################################################
## Daily mechanistic engine
###############################################################

DailyECF <- function(T, RH, H){
  
  ####################################################
  ## Tick persistence
  ####################################################
  
  Rv <- PersistenceRaster(T, RH, H)
  
  ####################################################
  ## Tick persistence probability
  ####################################################
  
  Ptick <- TickProbability(Rv)
  
  ####################################################
  ## Pathogen suitability
  ####################################################
  
  Ppath <- PathogenSuitability(T)
  
  Ppath <- pmin(
    1,
    pmax(
      0,
      Ppath
    )
  )
  
  ####################################################
  ## Integration pathways
  ####################################################
  
  MULT <-
    integration_multiplicative(
      Ptick,
      Ppath
    )
  
  LIMIT <-
    integration_limiting(
      Ptick,
      Ppath
    )
  
  ARITH <-
    integration_arithmetic(
      Ptick,
      Ppath
    )
  
  GEOM <-
    integration_geometric(
      Ptick,
      Ppath
    )
  
  ####################################################
  ## Weighted integrations
  ####################################################
  
  WeightedOutputs <-
    
    lapply(
      tick_weights,
      function(w){
        
        integration_weighted(
          Ptick,
          Ppath,
          weight = w
        )
        
      }
    )
  ####################################################
  ## Fuzzy integration
  ####################################################
  
  FUZZY <-
    integration_fuzzy(
      Ptick,
      Ppath
    )
  ####################################################
  ## Return outputs
  ####################################################
  
  do.call(
    cbind,
    c(
      
      list(
        
        Ptick,
        
        Ppath,
        
        MULT,
        
        LIMIT,
        
        ARITH,
        
        GEOM
        
      ),
      
      WeightedOutputs,
      
      list(
        
        FUZZY
        
      )
      
    )
  )
} 
###############################################################
## Daily simulation
###############################################################
RunOneDay <- function(
    Temperature,
    Humidity,
    outfile
){
  cat("Writing:", outfile, "\n")
  climate <- c(
    Temperature,
    Humidity,
    HostDensity
  )
  
  names(climate) <- c(
    "T",
    "RH",
    "H"
  )
  
  result <- lapp(
    climate,
    fun = DailyECF,
    cores = 1
  )
  
  cat("Returned layers:", nlyr(result), "\n")
  cat("Metric names:", length(metric_names), "\n")
  
  print(names(result))
  
  stop("Debug")
  
  dir.create(dirname(outfile), recursive = TRUE, showWarnings = FALSE)
  
  writeRaster(
    result,
    filename = outfile,
    overwrite = TRUE
  )
  
  cat("Exists after write:", file.exists(outfile), "\n")
  
  invisible(result)
}
###############################################################
## Read annual climate
###############################################################

LoadClimateYear <-
  
  function(year){
    
    Tfile <-
      
      file.path(
        
        climate_dir,
        
        paste0(
          
          "Temperature_C_ECF_daily_",
          
          year,
          
          ".nc"
          
        )
        
      )
    
    RHfile <-
      
      file.path(
        
        climate_dir,
        
        paste0(
          
          "RelativeHumidity_ECF_daily_",
          
          year,
          
          ".nc"
          
        )
        
      )
    
    if(!file.exists(Tfile))
      
      stop(Tfile)
    
    if(!file.exists(RHfile))
      
      stop(RHfile)
    
    Temperature <-
      
      rast(Tfile)
    
    Humidity <-
      
      rast(RHfile)
    
    if(
      
      nlyr(Temperature)!=
      
      nlyr(Humidity)
      
    )
      
      stop(
        
        "Different number of layers."
        
      )
    
    list(
      
      Temperature=Temperature,
      
      Humidity=Humidity
      
    )
    
  }
###############################################################
## Temporary files
###############################################################

TempDirectory <-
  
  function(year){
    
    folder <-
      
      file.path(
        
        output_dir,
        
        "Temp",
        
        year
        
      )
    
    dir.create(
      
      folder,
      
      recursive=TRUE,
      
      showWarnings=FALSE
      
    )
    
    folder
    
  }
###############################################################
## Simulate one year
###############################################################

RunYear <-
  
  function(year){
    
    cat(
      
      "\nProcessing",
      
      year,
      
      "\n"
      
    )
    
    Climate <-
      
      LoadClimateYear(
        
        year
        
      )
    
    TempFolder <-
      
      TempDirectory(
        
        year
        
      )
    
    ndays <-
      
      nlyr(
        
        Climate$Temperature
        
      )
    
    DailyFiles <-
      
      character(
        
        ndays
        
      )
    
    for(day in 1:ndays){
      
      outfile <-
        
        file.path(
          
          TempFolder,
          
          sprintf(
            
            "Day_%03d.tif",
            
            day
            
          )
          
        )
      
      DailyFiles[day] <-
        
        outfile
      
      if(
        
        resume &
        
        file.exists(outfile)
        
      ){
        
        cat(
          
          "Day",
          
          day,
          
          "already done\n"
          
        )
        
        next
        
      }
      
      RunOneDay(
        
        Climate$Temperature[[day]],
        
        Climate$Humidity[[day]],
        
        outfile
        
      )
      
      cat(
        
        sprintf(
          
          "%d/%d\n",
          
          day,
          
          ndays
          
        )
        
      )
      
      gc()
      
    }
    
    DailyFiles
    
  }
cat("\nChecking first few files...\n")


###############################################################
## Export annual NetCDF products
###############################################################

ExportAnnualNetCDF <- function(year, DailyFiles){
  
  cat("\nCreating annual NetCDF files...\n")
  
  metric_dirs <- setNames(
    
    rep(
      file.path(output_dir, "Integrated"),
      length(metric_names)
    ),
    
    metric_names
    
  )
  
  metric_dirs["Tick"] <- file.path(output_dir, "Tick")
  metric_dirs["Pathogen"] <- file.path(output_dir, "Pathogen")
  
  for(i in seq_along(metric_names)){
    
    cat(metric_names[i],"\n")
    
    annual_stack <- rast(lapply(DailyFiles,function(x){
      
      rast(x)[[i]]
      
    }))
    
    names(annual_stack) <-
      
      paste0(
        
        metric_names[i],
        
        "_Day_",
        
        sprintf("%03d",1:nlyr(annual_stack))
        
      )
    
    outfile <-
      
      file.path(
        
        metric_dirs[[ metric_names[i] ]],
        
        paste0(
          
          metric_names[i],
          
          "_",
          
          year,
          
          ".nc"
          
        )
        
      )
    
    writeCDF(
      
      annual_stack,
      
      filename=outfile,
      
      overwrite=TRUE,
      
      varname=metric_names[i],
      
      longname=paste(
        
        metric_names[i],
        
        "Daily suitability"
        
      ),
      
      unit="Probability"
      
    )
    
  }
  
}
###############################################################
## Remove temporary files
###############################################################

CleanupYear <- function(year){
  
  folder <-
    
    file.path(
      
      output_dir,
      
      "Temp",
      
      year
      
    )
  
  if(dir.exists(folder)){
    
    unlink(
      
      folder,
      
      recursive=TRUE,
      
      force=TRUE
      
    )
    
  }
  
}
###############################################################
## Logging
###############################################################

WriteLog <- function(
    
  year,
  
  runtime
  
){
  
  logfile <-
    
    file.path(
      
      output_dir,
      
      "Logs",
      
      paste0(
        
        "Run_",
        
        year,
        
        ".txt"
        
      )
      
    )
  
  writeLines(
    
    c(
      
      paste("Year:",year),
      
      paste("Finished:",Sys.time()),
      
      paste(
        
        "Runtime (minutes):",
        
        round(runtime,2)
        
      )
      
    ),
    
    logfile
    
  )
  
}
###############################################################
## Run simulation
###############################################################

for(year in years){
  
  start_time <- Sys.time()
  
  cat(
    
    "\n=====================================\n"
    
  )
  
  cat(
    
    "YEAR",
    
    year,
    
    "\n"
    
  )
  
  cat(
    
    "=====================================\n"
    
  )
  
  DailyFiles <-
    
    RunYear(year)
  
  ExportAnnualNetCDF(
    
    year,
    
    DailyFiles
    
  )
  
  CleanupYear(
    
    year
    
  )
  
  runtime <-
    
    difftime(
      
      Sys.time(),
      
      start_time,
      
      units="mins"
      
    )
  
  WriteLog(
    
    year,
    
    runtime
    
  )
  
  gc()
  
}
###############################################################
## Finished
###############################################################

cat(
  
  "\n=======================================\n"
  
)

cat(
  
  "East Coast Fever simulation completed.\n"
  
)

cat(
  
  "Outputs written to:\n"
  
)

cat(
  
  normalizePath(output_dir),
  
  "\n"
  
)

cat(
  
  "=======================================\n"
  
)
