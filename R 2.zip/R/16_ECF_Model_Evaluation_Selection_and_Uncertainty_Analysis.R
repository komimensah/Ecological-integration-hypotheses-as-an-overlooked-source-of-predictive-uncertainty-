################################################################################
# 16_ECF_Model_Evaluation_Selection_and_Uncertainty_Analysis_v2.R
#
# PART 1 : INITIALIZATION AND AUTOMATIC DISCOVERY
################################################################################

rm(list = ls())
gc()

cat("\014")

################################################################################
# Libraries
################################################################################

required_packages <- c(
  "terra",
  "sf",
  "dplyr",
  "stringr",
  "purrr",
  "tidyr",
  "ggplot2",
  "ecospat",
  "pROC",
  "effsize"
)
invisible(
  lapply(required_packages, library,
         character.only = TRUE)
)

################################################################################
# Directories
################################################################################

project_dir <- "/Users/kagboka/Desktop/R.appendi"

prediction_dir <- file.path(
  project_dir,
  "ECF_PostProcessed"
)

evaluation_dir <- file.path(
  project_dir,
  "Outputs",
  "16_Model_Evaluation_v2"
)

dir.create(
  evaluation_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

################################################################################
# Occurrence data
################################################################################

occ <- read.csv(
  file.path(
    project_dir,
    "ECF_Occurrence_Sites.csv"
  )
)

occ <- occ %>%
  dplyr::filter(Presence == 1)

cat("Occurrence records :", nrow(occ), "\n")

occ_vect <- terra::vect(
  occ,
  geom = c("East","North"),
  crs = "EPSG:4326"
)

################################################################################
# Discover prediction rasters
################################################################################

prediction_files <- list.files(
  prediction_dir,
  recursive = TRUE,
  full.names = TRUE,
  pattern = "\\.nc$"
)

cat("Prediction files discovered :", length(prediction_files), "\n")

if(length(prediction_files)==0)
  stop("No NetCDF files found.")

################################################################################
# Build raster inventory
################################################################################

PredictionInventory <- purrr::map_df(
  prediction_files,
  function(f){
    
    r <- terra::rast(f)
    
    data.frame(
      
      File = f,
      
      Filename = basename(f),
      
      Folder = basename(dirname(f)),
      
      Product = tools::file_path_sans_ext(
        basename(f)
      ),
      
      NLayers = terra::nlyr(r),
      
      NRows = nrow(r),
      
      NCols = ncol(r),
      
      Resolution_X = terra::res(r)[1],
      
      Resolution_Y = terra::res(r)[2],
      
      CRS = terra::crs(r),
      
      stringsAsFactors = FALSE
      
    )
    
  }
)

################################################################################
# Classify product family
################################################################################

PredictionInventory$Family <- case_when(
  
  str_detect(
    PredictionInventory$Product,
    "Monthly"
  ) ~ "Monthly",
  
  str_detect(
    PredictionInventory$Product,
    "Seasonal"
  ) ~ "Seasonal",
  
  str_detect(
    PredictionInventory$Product,
    "Quarterly"
  ) ~ "Quarterly",
  
  str_detect(
    PredictionInventory$Product,
    "Persistence"
  ) ~ "Persistence",
  
  str_detect(
    PredictionInventory$Product,
    "Suitable"
  ) ~ "SuitableDays",
  
  str_detect(
    PredictionInventory$Product,
    "Trend"
  ) ~ "Trend",
  
  str_detect(
    PredictionInventory$Product,
    "Variability"
  ) ~ "Variability",
  
  TRUE ~ "Other"
  
)

################################################################################
# Which products are suitable for Boyce?
################################################################################

PredictionInventory$EvaluateBoyce <-
  stringr::str_detect(
    PredictionInventory$Filename,
    "LongTermMean"
  )

################################################################################
# Create evaluation inventory
################################################################################

EvaluationInventory <-
  PredictionInventory %>%
  dplyr::filter(EvaluateBoyce)

cat("\n")
cat("Products selected for Boyce evaluation:\n")
print(EvaluationInventory[, c("Filename", "Folder")])
write.csv(
  EvaluationInventory,
  file.path(
    evaluation_dir,
    "EvaluationInventory.csv"
  ),
  row.names = FALSE
)
################################################################################
# Save inventory
################################################################################

write.csv(
  PredictionInventory,
  file.path(
    evaluation_dir,
    "PredictionInventory.csv"
  ),
  row.names = FALSE
)

################################################################################
# Summary
################################################################################

cat("\n")
cat("=========================================\n")
cat("Prediction Inventory\n")
cat("=========================================\n")

print(
  PredictionInventory %>%
    count(Family)
)

cat("\nProducts selected for Boyce evaluation:\n")

print(
  PredictionInventory %>%
    filter(EvaluateBoyce)
)



################################################################################
# PART 2 : BUILD EVALUATION DATASET
################################################################################

cat("\n")
cat("=========================================\n")
cat("Preparing evaluation dataset\n")
cat("=========================================\n")

################################################################################
# Reference raster
################################################################################

reference_file <-
  PredictionInventory %>%
  slice(1) %>%
  pull(File)

reference_raster <-
  terra::rast(reference_file)

# Always use first layer as spatial reference
reference_raster <-
  reference_raster[[1]]

################################################################################
# Sample valid cells
################################################################################

valid_cells <-
  which(
    !is.na(
      terra::values(reference_raster)
    )
  )

cat("Valid raster cells:",
    length(valid_cells),
    "\n")

################################################################################
# Background points
################################################################################

set.seed(1234)

n_background <-
  min(
    10000,
    length(valid_cells)
  )

selected_cells <-
  sample(
    valid_cells,
    n_background
  )

xy <-
  terra::xyFromCell(
    reference_raster,
    selected_cells
  )

background <-
  data.frame(
    
    East = xy[,1],
    
    North = xy[,2]
    
  )

################################################################################
# Convert to sf
################################################################################

background_sf <-
  sf::st_as_sf(
    
    background,
    
    coords = c("East","North"),
    
    crs = 4326
    
  )

################################################################################
# Save
################################################################################

write.csv(
  
  background,
  
  file.path(
    evaluation_dir,
    "Background_Points.csv"
  ),
  
  row.names = FALSE
  
)

################################################################################
# Summary
################################################################################

cat("\n")

cat("Presence records :",
    nrow(occ),
    "\n")

cat("Background points:",
    nrow(background),
    "\n")

cat("Evaluation dataset ready.\n")




################################################################################
# PART 3 : PREPARE PREDICTION SURFACES
################################################################################

cat("\n")
cat("=========================================\n")
cat("Preparing prediction surfaces\n")
cat("=========================================\n")

################################################################################
# Select products suitable for Boyce evaluation
################################################################################

EvaluationInventory <-
  
  PredictionInventory %>%
  
  filter(EvaluateBoyce)

cat("Products selected:",
    nrow(EvaluationInventory),
    "\n")

################################################################################
# Read prediction surfaces
################################################################################

PredictionSurfaces <- vector(
  "list",
  nrow(EvaluationInventory)
)

################################################################################
# Loop through products
################################################################################

for(i in seq_len(nrow(EvaluationInventory))){
  
  cat(i,"/",nrow(EvaluationInventory),
      EvaluationInventory$Filename[i],"\n")
  
  r <- terra::rast(
    EvaluationInventory$File[i]
  )
  
  ############################################################
  # Convert multilayer NetCDF to one suitability surface
  ############################################################
  
  if(terra::nlyr(r)==1){
    
    surface <- r
    
  }else{
    
    ## Mean suitability across layers
    
    surface <- terra::app(
      r,
      mean,
      na.rm=TRUE
    )
    
  }
  

  ############################################################
  # Store
  ############################################################
  
  PredictionSurfaces[[i]] <- list(
    
    Filename = EvaluationInventory$Filename[i],
    
    Method = EvaluationInventory$Folder[i],
    
    Family = EvaluationInventory$Family[i],
    
    Product = EvaluationInventory$Product[i],
    
    Threshold = stringr::str_extract(
      EvaluationInventory$Product[i],
      "025|050|075"
    ),
    
    Metric = dplyr::case_when(
      
      stringr::str_detect(
        EvaluationInventory$Product[i],
        "PercentYearsSuitable"
      ) ~ "PercentYearsSuitable",
      
      stringr::str_detect(
        EvaluationInventory$Product[i],
        "YearsSuitable"
      ) ~ "YearsSuitable",
      
      TRUE ~ "Other"
      
    ),
    
    Raster = surface
    
  )
  
}   # <-- closes the for loop

cat("\n")
cat(length(PredictionSurfaces),
    "prediction surfaces prepared.\n")


################################################################################
# PART 4 : CONTINUOUS BOYCE EVALUATION
################################################################################

cat("\n")
cat("=====================================================\n")
cat("Running Continuous Boyce Evaluation\n")
cat("=====================================================\n")

BoyceResults <- vector("list", length(PredictionSurfaces))

for(i in seq_along(PredictionSurfaces)){
  
  cat(i,"/",length(PredictionSurfaces),
      PredictionSurfaces[[i]]$Filename,"\n")
  
  r <- PredictionSurfaces[[i]]$Raster
  
  ##########################################################################
  # Extract predictions
  ##########################################################################
  
  PresenceValues <- terra::extract(
    r,
    occ_vect
  )[,2]
  
  BackgroundValues <- terra::extract(
    r,
    background_sf
  )[,2]
  
  PresenceValues <- PresenceValues[!is.na(PresenceValues)]
  BackgroundValues <- BackgroundValues[!is.na(BackgroundValues)]
 
  ##########################################################################
  # Wilcoxon test
  ##########################################################################
  
  WilcoxP <- tryCatch({
    
    wilcox.test(
      PresenceValues,
      BackgroundValues
    )$p.value
    
  }, error=function(e) NA_real_)
  
  ##########################################################################
  # Cliff's Delta
  ##########################################################################
  
  CliffsDelta <- tryCatch({
    
    effsize::cliff.delta(
      PresenceValues,
      BackgroundValues
    )$estimate
    
  }, error=function(e) NA_real_)
  
  ##########################################################################
  # Skip empty datasets
  ##########################################################################
  
  if(length(PresenceValues) < 10 ||
     length(BackgroundValues) < 10){
    
    BoyceScore <- NA_real_
    
  }else{
    
    boyce <- tryCatch(
      
      ecospat::ecospat.boyce(
        
        fit = BackgroundValues,
        
        obs = PresenceValues,
        
        PEplot = FALSE
        
      ),
      
      error = function(e) NULL
      
    )
    
    if(is.null(boyce)){
      
      BoyceScore <- NA_real_
      
    }else if("cor" %in% names(boyce)){
      
      BoyceScore <- as.numeric(boyce$cor)
      
    }else{
      
      BoyceScore <- NA_real_
      
    }
    
  }
  
  ##########################################################################
  # Store results
  ##########################################################################
  
  ##########################################################################
  # Store results
  ##########################################################################
  
  Method <-
    
    stringr::str_remove(
      EvaluationInventory$Filename[i],
      "_LongTermMean\\.nc"
    )
  
  Weight <-
    
    dplyr::case_when(
      
      grepl("^Weighted_", Method) ~
        
        as.numeric(
          stringr::str_extract(
            Method,
            "[0-9]+"
          )
        ) / 100,
      
      TRUE ~ NA_real_
      
    )
  
  BoyceResults[[i]] <- data.frame(
    
    Filename = PredictionSurfaces[[i]]$Filename,
    
    Method = Method,
    
    Weight = Weight,
    
    Metric = PredictionSurfaces[[i]]$Metric,
    
    Threshold = PredictionSurfaces[[i]]$Threshold,
    
    Boyce = BoyceScore,
    
    WilcoxonP = WilcoxP,
    
    CliffsDelta = CliffsDelta,
    
    MeanPresence = mean(
      PresenceValues,
      na.rm = TRUE
    ),
    
    MeanBackground = mean(
      BackgroundValues,
      na.rm = TRUE
    ),
    
    Difference =
      mean(
        PresenceValues,
        na.rm = TRUE
      ) -
      mean(
        BackgroundValues,
        na.rm = TRUE
      ),
    
    SDPresence = sd(
      PresenceValues,
      na.rm = TRUE
    ),
    
    SDBackground = sd(
      BackgroundValues,
      na.rm = TRUE
    ),
    
    NPresence = length(PresenceValues),
    
    NBackground = length(BackgroundValues)
    
  )
  
}   # <-- closes the for loop
################################################################################
# Combine results
################################################################################

BoyceResults <- dplyr::bind_rows(BoyceResults)

################################################################################
# Rank models
################################################################################

BoyceResults <- BoyceResults %>%
  arrange(desc(Boyce))

################################################################################
# Save
################################################################################

write.csv(
  BoyceResults,
  file.path(
    evaluation_dir,
    "BoyceResults.csv"
  ),
  row.names = FALSE
)

################################################################################
# Show results
################################################################################

cat("\n")
cat("Top 10 models\n\n")

print(
  BoyceResults[1:10,]
)
################################################################################
# FIGURE 3
# Comparative evaluation of integration hypotheses
################################################################################

library(ggplot2)
library(dplyr)
library(stringr)
library(patchwork)

################################################################################
# Prepare data
################################################################################

EvaluationResults <- BoyceResults

EvaluationResults <- EvaluationResults %>%
  mutate(
    Method = case_when(
      grepl("^Weighted_", Method) ~
        paste0("Weighted ",
               str_extract(Method,"[0-9]+"),
               "%"),
      TRUE ~ Method
    )
  )

# Remove duplicates
EvaluationResults <- EvaluationResults %>%
  filter(
    !Method %in% c(
      "Weighted",
      "Weighted 50%"
    )
  )

# Order by Boyce
EvaluationResults <- EvaluationResults %>%
  arrange(desc(Boyce))

EvaluationResults$Method <-
  factor(
    EvaluationResults$Method,
    levels = rev(EvaluationResults$Method)
  )

################################################################################
# PANEL A
################################################################################

pA <-

ggplot(
  EvaluationResults,
  aes(Method, Boyce, fill = Highlight)
)+

geom_col(width = 0.7)+

coord_flip()+

scale_fill_manual(
  values = c(
    Best = "#2C7FB8",
    Other = "grey60"
  ),
  guide = "none"
)+

  labs(
    title = "A",
    x = "",
    y = "Continuous Boyce Index"
  )+
  
  theme(
    panel.grid = element_blank(),
    axis.title = element_text(face = "bold"),
    axis.text = element_text(colour = "black"),
    plot.title = element_text(face = "bold", hjust = 0)
  )+

theme_bw(base_size = 14)+

theme(

  panel.grid = element_blank(),

  axis.title = element_text(face="bold"),

  axis.text = element_text(colour="black")

)
################################################################################
# PANEL B
# Weight sensitivity
################################################################################

WeightedResults <-
  
  BoyceResults %>%
  
  filter(grepl("^Weighted_", Method)) %>%
  
  mutate(
    Weight = as.numeric(gsub("Weighted_", "", Method))
  ) %>%
  
  arrange(Weight)

BestWeight <-
  
  WeightedResults %>%
  
  slice_max(Boyce, n = 1)

pB <-
  
  ggplot(
    WeightedResults,
    aes(Weight, Boyce)
  )+
  
  geom_line(
    linewidth = 1.2,
    colour = "black"
  )+
  
  geom_point(
    size = 3.8,
    shape = 21,
    fill = "white",
    colour = "black"
  )+
  
  geom_point(
    data = BestWeight,
    size = 5,
    shape = 21,
    fill = "#D7191C",
    colour = "black"
  )+
  
  
  scale_x_continuous(
    breaks = seq(10,90,10),
    labels = paste0(seq(10,90,10),"%")
  )+
  
  labs(
    title = "B",
    x = "Vector persistence contribution (%)",
    y = "Continuous Boyce Index"
  )+
  
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(colour = "grey90"),
    axis.title = element_text(face = "bold"),
    axis.text = element_text(colour = "black"),
    plot.title = element_text(face = "bold", hjust = 0)
  )+
  
  theme_bw(base_size = 14)+
  
  theme(
    
    panel.grid.minor = element_blank(),
    
    panel.grid.major = element_line(colour="grey90"),
    
    axis.title = element_text(face="bold"),
    
    axis.text = element_text(colour="black")
    
  )

################################################################################
# FINAL FIGURE
################################################################################

Figure3 <-
  
  pA | pB +
  
  plot_annotation(
    tag_levels = "A"
  )

################################################################################
# SAVE
################################################################################

print(Figure3)

ggsave(
  
  file.path(
    evaluation_dir,
    "Figure3_Model_Comparison.png"
  ),
  
  Figure3,
  
  width = 11,
  
  height = 5.5,
  
  dpi = 600,
  
  bg = "white"
  
)

ggsave(
  
  file.path(
    evaluation_dir,
    "Figure3_Model_Comparison.pdf"
  ),
  
  Figure3,
  
  width = 11,
  
  height = 5.5,
  
  bg = "white"
  
)
