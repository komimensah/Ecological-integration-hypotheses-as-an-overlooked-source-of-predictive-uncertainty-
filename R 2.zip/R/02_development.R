###############################################################
# Tick Persistence Framework
# File        : 02_development.R
# Purpose     : Temperature-dependent development functions
#
# Source:
# Tukahirwa (1976)
#
# Notes
# -----
# • Uses original fitted equation for the ascending limb.
# • Uses laboratory thermal constraints to generate the
#   descending limb.
# • Fully vectorized.
###############################################################


###############################################################
## Check parameter object
###############################################################

if (!exists("params")) {
  stop(
    "Parameter object 'params' not found.\n",
    "Run 01_parameters.R first."
  )
}


###############################################################
## Generic development function
###############################################################

development_rate <- function(T, stage){
  
  #############################################################
  ## Read parameters
  #############################################################
  
  p <- params$development[[stage]]
  
  required <- c(
    "slope",
    "intercept",
    "Tmin",
    "Topt",
    "Tmax"
  )
  
  miss <- setdiff(required, names(p))
  
  if(length(miss) > 0){
    
    stop(
      "Missing parameters: ",
      paste(miss, collapse = ", ")
    )
    
  }
  
  #############################################################
  ## Temperature
  #############################################################
  
  T <- as.numeric(T)
  
  rate <- rep(0, length(T))
  
  rate[is.na(T)] <- NA_real_
  
  #############################################################
  ## Biological interval
  #############################################################
  
  inside <-
    !is.na(T) &
    T > p$Tmin &
    T < p$Tmax
  
  if(!any(inside))
    return(rate)
  
  #############################################################
  ## Peak development from Tukahirwa
  #############################################################
  
  Gmax <-
    p$slope *
    (p$Topt - p$intercept) / 100
  
  Gmax <- max(Gmax,0)
  
  #############################################################
  ## Shape parameters
  ##
  ## Can later become stage-specific if desired
  #############################################################
  
  alpha <- 2.2
  beta  <- 1.8
  
  #############################################################
  ## Normalised temperatures
  #############################################################
  
  x <-
    (T[inside] - p$Tmin) /
    (p$Tmax - p$Tmin)
  
  xopt <-
    (p$Topt - p$Tmin) /
    (p$Tmax - p$Tmin)
  
  #############################################################
  ## Beta thermal performance
  #############################################################
  
  f <-
    (x^alpha) *
    ((1-x)^beta)
  
  fopt <-
    (xopt^alpha) *
    ((1-xopt)^beta)
  
  rate[inside] <-
    Gmax *
    f /
    fopt
  
  #############################################################
  ## Numerical safety
  #############################################################
  
  rate <- pmax(rate,0)
  
  return(rate)
  
}
###############################################################
## Stage wrappers
###############################################################

G_E <- function(T){
  
  development_rate(T, "egg")
  
}


G_L <- function(T){
  
  development_rate(T, "larva")
  
}


G_N <- function(T){
  
  development_rate(T, "nymph")
  
}


G_A <- function(T){
  
  development_rate(T, "adult")
  
}


###############################################################
## Return all development rates
###############################################################

development_rates <- function(T){
  
  data.frame(
    
    Temperature = T,
    
    Egg = G_E(T),
    
    Larva = G_L(T),
    
    Nymph = G_N(T),
    
    Adult = G_A(T)
    
  )
  
}


###############################################################
## Plot development rates
###############################################################

plot_development <- function(T = seq(-5, 50, 0.1)){
  
  rates <- development_rates(T)
  
  matplot(
    rates$Temperature,
    rates[,2:5],
    type = "l",
    lty = 1,
    lwd = 2,
    xlab = "Temperature (°C)",
    ylab = "Development rate (day⁻¹)"
  )
  
  legend(
    "topleft",
    legend = c(
      "Egg",
      "Larva",
      "Nymph",
      "Adult"
    ),
    lty = 1,
    lwd = 2,
    bty = "n"
  )
  
}