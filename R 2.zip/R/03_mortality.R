###############################################################
# Tick Persistence Framework
# File        : 03_mortality.R
# Purpose     : Stage-specific mortality functions
#
# Sources
# -------
# Tukahirwa (1976)
# Short et al. (1989)
#
# Notes
# -----
# • Fully vectorized
# • Uses parameters from params
# • No persistence calculations
###############################################################


###############################################################
## Check parameter object
###############################################################

if (!exists("params")) {
  stop("Parameter object 'params' not found.\nRun 01_parameters.R first.")
}


###############################################################
## Generic logistic function
###############################################################

logistic_function <- function(x, beta0, beta1){
  
  1 / (1 + exp(beta0 + beta1 * x))
  
}


###############################################################
## Stage survival probability
###############################################################

stage_probability <- function(stage, RH = NULL){
  
  switch(
    
    stage,
    
    egg =
      logistic_function(
        RH,
        params$egg_hatch$beta0,
        params$egg_hatch$beta1
      ),
    
    larva =
      logistic_function(
        RH,
        params$larval_moult$beta0,
        params$larval_moult$beta1
      ),
    
    nymph =
      rep(
        params$nymph_moult$survival,
        length.out = max(1, length(RH))
      ),
    
    adult =
      rep(
        params$female_survival$survival,
        length.out = max(1, length(RH))
      ),
    
    stop("Unknown stage.")
    
  )
  
}


###############################################################
## Generic mortality function
##
## Derives the instantaneous mortality rate from the
## probability of surviving a stage.
##
## P = exp(-M × D)
##
## where
##   D = 1/G
##
## therefore
##
##   M = -log(P) × G
###############################################################

stage_mortality <- function(G, P){
  
  #############################################################
  ## Numerical safety
  #############################################################
  
  P <- pmin(pmax(P, 1e-8), 1 - 1e-8)
  
  #############################################################
  ## Mortality rate
  #############################################################
  
  M <- -log(P) * G
  
  return(M)
  
}


###############################################################
## Egg mortality
###############################################################

M_E <- function(T, RH){
  
  stage_mortality(
    
    G = G_E(T),
    
    P = stage_probability("egg", RH)
    
  )
  
}


###############################################################
## Larval mortality
###############################################################

M_L <- function(T, RH){
  
  stage_mortality(
    
    G = G_L(T),
    
    P = stage_probability("larva", RH)
    
  )
  
}


###############################################################
## Nymph mortality
###############################################################

M_N <- function(T){
  
  stage_mortality(
    
    G = G_N(T),
    
    P = stage_probability("nymph", RH = T)
    
  )
  
}


###############################################################
## Adult mortality
###############################################################

M_A <- function(T){
  
  stage_mortality(
    
    G = G_A(T),
    
    P = stage_probability("adult", RH = T)
    
  )
  
}


###############################################################
## Bootstrap helper
###############################################################

bootstrap_sample <- function(x, n = 1){
  
  sample(
    
    x,
    
    size = n,
    
    replace = TRUE
    
  )
  
}

###############################################################
## Draw one questing mortality parameter set
###############################################################

draw_questing_parameters <- function(n = 1){
  
  data.frame(
    
    larva = bootstrap_sample(
      params$bootstrap$quest_larva,
      n
    ),
    
    nymph = bootstrap_sample(
      params$bootstrap$quest_nymph,
      n
    ),
    
    adult = bootstrap_sample(
      params$bootstrap$quest_adult,
      n
    )
    
  )
  
}
###############################################################
## Questing mortality
###############################################################

M_QuestLarva <- function(n = 1, pars = NULL){
  
  if(is.null(pars)){
    
    S50 <- bootstrap_sample(
      params$bootstrap$quest_larva,
      n
    )
    
  } else {
    
    S50 <- pars$larva
    
  }
  
  log(2) / S50
  
}



M_QuestNymph <- function(n = 1, pars = NULL){
  
  if(is.null(pars)){
    
    S50 <- bootstrap_sample(
      params$bootstrap$quest_nymph,
      n
    )
    
  } else {
    
    S50 <- pars$nymph
    
  }
  
  log(2) / S50
  
}



M_QuestAdult <- function(n = 1, pars = NULL){
  
  if(is.null(pars)){
    
    S50 <- bootstrap_sample(
      params$bootstrap$quest_adult,
      n
    )
    
  } else {
    
    S50 <- pars$adult
    
  }
  
  log(2) / S50
  
}


###############################################################
## Summary mortality table
###############################################################

mortality_rates <- function(T, RH){
  
  data.frame(
    
    Temperature = T,
    
    RH = RH,
    
    Egg = M_E(T, RH),
    
    Larva = M_L(T, RH),
    
    Nymph = M_N(T),
    
    Adult = M_A(T)
    
  )
  
}