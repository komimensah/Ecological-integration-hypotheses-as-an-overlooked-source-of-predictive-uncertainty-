###############################################################
# Tick Persistence Framework
# File        : 09_biological_verification.R
# Purpose     : Inspect biological behaviour of the model
###############################################################

library(ggplot2)
library(dplyr)
library(tidyr)

###############################################################
## Environmental gradients
###############################################################

Temperature <- seq(10,40,0.25)

Humidity <- seq(40,100,1)

###############################################################
## Development
###############################################################

Development <- development_rates(Temperature)

print(Development)

###############################################################
## Mortality
###############################################################

Mortality <- mortality_rates(
  
  Temperature,
  
  RH = 85
  
)

print(Mortality)

###############################################################
## Egg hatch
###############################################################

EggHatch <- data.frame(
  
  RH = Humidity,
  
  Hatch = sapply(
    
    Humidity,
    
    function(x)
      
      1 - M_E(
        
        T = 25,
        
        RH = x
        
      )
    
  )
  
)

###############################################################
## Larval survival
###############################################################

LarvalSurvival <- data.frame(
  
  RH = Humidity,
  
  Survival = sapply(
    
    Humidity,
    
    function(x)
      
      1 - M_L(
        
        T = 25,
        
        RH = x
        
      )
    
  )
  
)

###############################################################
## Effective fecundity
###############################################################

Fecundity <- data.frame(
  
  F = compute_F(5000)
  
)

###############################################################
## Persistence-temperature profile
###############################################################

PersistenceTemperature <-
  
  TemperatureProfile(
    
    T = Temperature,
    
    RH = 85,
    
    nsim = 1000
    
  )

###############################################################
## Persistence-humidity profile
###############################################################

PersistenceHumidity <-
  
  HumidityProfile(
    
    RH = Humidity,
    
    T = 25,
    
    nsim = 1000
    
  )

###############################################################
## Biological summaries
###############################################################

cat("\n")

cat("---------------------------------------\n")

cat("BIOLOGICAL SUMMARY\n")

cat("---------------------------------------\n")

cat("\n")

cat(
  
  "Mean fecundity : ",
  
  mean(Fecundity$F),
  
  "\n"
  
)

cat(
  
  "Median fecundity : ",
  
  median(Fecundity$F),
  
  "\n"
  
)

cat(
  
  "Maximum persistence : ",
  
  max(PersistenceTemperature$Mean),
  
  "\n"
  
)

cat(
  
  "Optimum temperature : ",
  
  PersistenceTemperature$Temperature[
    
    which.max(
      
      PersistenceTemperature$Mean
      
    )
    
  ],
  
  "\n"
  
)

cat(
  
  "Lower thermal limit : ",
  
  min(
    
    PersistenceTemperature$Temperature[
      
      PersistenceTemperature$Mean>1
      
    ]
    
  ),
  
  "\n"
  
)

cat(
  
  "Upper thermal limit : ",
  
  max(
    
    PersistenceTemperature$Temperature[
      
      PersistenceTemperature$Mean>1
      
    ]
    
  ),
  
  "\n"
  
)

###############################################################
## Figure 1
###############################################################

DevelopmentLong <-
  pivot_longer(
    Development,
    -Temperature,
    names_to = "Stage",
    values_to = "Rate"
  )

ggplot(
  
  DevelopmentLong,
  
  aes(
    
    Temperature,
    
    Rate,
    
    colour=Stage
    
  )
  
)+
  
  geom_line(
    
    linewidth=1.2
    
  )+
  
  theme_classic(
    
    base_size=14
    
  )+
  
  labs(
    
    y="Development rate"
    
  )

###############################################################
## Figure 2
###############################################################

MortalityLong <-
  pivot_longer(
    Mortality,
    cols = -Temperature,
    names_to = "Stage",
    values_to = "Mortality"
  )

ggplot(
  
  MortalityLong,
  
  aes(
    
    Temperature,
    
    Mortality,
    
    colour=Stage
    
  )
  
)+
  
  geom_line(
    
    linewidth=1.2
    
  )+
  
  theme_classic(
    
    base_size=14
    
  )

###############################################################
## Figure 3
###############################################################

ggplot(
  
  EggHatch,
  
  aes(
    
    RH,
    
    Hatch
    
  )
  
)+
  
  geom_line(
    
    linewidth=1.3,
    
    colour="blue"
    
  )+
  
  theme_classic(
    
    base_size=14
    
  )

###############################################################
## Figure 4
###############################################################

ggplot(
  
  LarvalSurvival,
  
  aes(
    
    RH,
    
    Survival
    
  )
  
)+
  
  geom_line(
    
    linewidth=1.3,
    
    colour="darkgreen"
    
  )+
  
  theme_classic(
    
    base_size=14
    
  )

###############################################################
## Figure 5
###############################################################

ggplot(
  
  Fecundity,
  
  aes(
    
    F
    
  )
  
)+
  
  geom_histogram(
    
    bins=30,
    
    fill="steelblue",
    
    colour="black"
    
  )+
  
  theme_classic(
    
    base_size=14
    
  )

###############################################################
## Figure 6
###############################################################

ggplot(
  
  PersistenceTemperature,
  
  aes(
    
    Temperature,
    
    Mean
    
  )
  
)+
  
  geom_line(
    
    linewidth=1.3,
    
    colour="red"
    
  )+
  
  geom_ribbon(
    
    aes(
      
      ymin=Lower95,
      
      ymax=Upper95
      
    ),
    
    alpha=0.20
    
  )+
  
  geom_hline(
    
    yintercept=1,
    
    linetype=2
    
  )+
  
  theme_classic(
    
    base_size=14
    
  )+
  
  labs(
    
    y="Persistence"
    
  )

###############################################################
## Figure 7
###############################################################

ggplot(
  
  PersistenceHumidity,
  
  aes(
    
    RH,
    
    Mean
    
  )
  
)+
  
  geom_line(
    
    linewidth=1.3,
    
    colour="purple"
    
  )+
  
  geom_ribbon(
    
    aes(
      
      ymin=Lower95,
      
      ymax=Upper95
      
    ),
    
    alpha=0.20
    
  )+
  
  geom_hline(
    
    yintercept=1,
    
    linetype=2
    
  )+
  
  theme_classic(
    
    base_size=14
    
  )+
  
  labs(
    
    y="Persistence"
    
  )

###############################################################
## Export outputs
###############################################################

write.csv(
  
  Development,
  
  "Development.csv",
  
  row.names=FALSE
  
)

write.csv(
  
  Mortality,
  
  "Mortality.csv",
  
  row.names=FALSE
  
)

write.csv(
  
  EggHatch,
  
  "EggHatch.csv",
  
  row.names=FALSE
  
)

write.csv(
  
  LarvalSurvival,
  
  "LarvalSurvival.csv",
  
  row.names=FALSE
  
)

write.csv(
  
  Fecundity,
  
  "Fecundity.csv",
  
  row.names=FALSE
  
)

write.csv(
  
  PersistenceTemperature,
  
  "PersistenceTemperature.csv",
  
  row.names=FALSE
  
)

write.csv(
  
  PersistenceHumidity,
  
  "PersistenceHumidity.csv",
  
  row.names=FALSE
  
)

cat("\n")

cat("---------------------------------------\n")

cat("Inspection completed successfully.\n")

cat("---------------------------------------\n")